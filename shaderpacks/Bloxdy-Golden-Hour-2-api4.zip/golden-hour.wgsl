// Bloxd shader-pack API 4. Keep the engine's light and fog as the base.
// The pack adds colour and contrast; it does not create new shadow geometry.

fn ghWetMaterial(flags: u32) -> bool {
    return (flags & (bloxdBlockFlagDirt | bloxdBlockFlagRock)) != 0u;
}

fn ghGoldenAmount() -> f32 {
    let sun = bloxdSunDirection();
    let daylight = smoothstep(0.01, 0.15, sun.y);
    let lowSun = 1.0 - smoothstep(0.18, 0.65, sun.y);
    return daylight * (0.55 + 0.45 * lowSun);
}

fn bloxdTerrainSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    var result = bloxdDefaultSurface(surface);
    // A visible baseline in both lit and unlit worlds.
    result.colour *= vec3f(1.16, 1.055, 0.76);
    // Subtle damp stone/soil. No weather input is available to this pack.
    if (surface.normal.y > 0.85 && ghWetMaterial(surface.blockFlags)) {
        result.colour *= vec3f(0.83, 0.87, 0.91);
    }
    return result;
}

fn bloxdTerrainLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    var result = bloxdDefaultLight(surface, light);
    _ = surface;
#ifdef BLOXD_LIGHTING
    let sun = bloxdSunDirection();
    let golden = ghGoldenAmount();
    let exposed = smoothstep(0.55, 0.97, light.skyLight);
    let lamp = max(light.blockLight.r, max(light.blockLight.g, light.blockLight.b));
    let daylightOnly = 1.0 - smoothstep(0.35, 0.8, lamp);
    let faceSun = smoothstep(-0.12, 0.42, dot(light.normal, sun));
    let direct = golden * exposed * daylightOnly * faceSun;
    // A small drop in sky light is already the engine's canopy shadow signal.
    let canopy = clamp((1.0 - light.skyLight) / 0.006, 0.0, 1.0)
        * smoothstep(0.55, 0.9, light.skyLight)
        * golden * daylightOnly;
    let shade = 1.0 - 0.32 * canopy;
    let sunlight = mix(vec3f(1.0), vec3f(1.16, 1.07, 0.86), direct);
    // API 4: fogAlpha is zero without fog; keep distant fog at engine colour.
    let effect = (1.0 - light.fogAlpha);
    result.colour *= mix(vec3f(1.0), sunlight * shade, effect);
    if (light.normal.y > 0.85 && ghWetMaterial(light.blockFlags)) {
        let toEye = bloxdEyePosition() - light.position;
        let eyeLength = length(toEye);
        if (eyeLength > 0.001) {
            let view = toEye / eyeLength;
            let halfVector = view + sun;
            let halfLength = length(halfVector);
            if (halfLength > 0.001) {
                let glint = pow(max(dot(light.normal, halfVector / halfLength), 0.0), 28.0);
                result.colour += vec3f(1.0, 0.68, 0.35)
                    * glint * golden * exposed * daylightOnly * effect * 0.07;
            }
        }
    }
#endif
    return result;
}

fn bloxdLiquidSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    var result = bloxdDefaultSurface(surface);
    result.colour *= vec3f(1.08, 1.025, 0.82);
    return result;
}

fn bloxdLiquidLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    var result = bloxdDefaultLight(surface, light);
    _ = surface;
#ifdef BLOXD_LIGHTING
    let sun = bloxdSunDirection();
    let golden = ghGoldenAmount();
    let exposed = smoothstep(0.55, 0.97, light.skyLight);
    let effect = (1.0 - light.fogAlpha) * golden * exposed;
    result.colour *= mix(vec3f(1.0), vec3f(1.10, 1.025, 0.89), effect * 0.65);
    let toEye = bloxdEyePosition() - light.position;
    let eyeLength = length(toEye);
    if (eyeLength > 0.001) {
        let view = toEye / eyeLength;
        let halfVector = view + sun;
        let halfLength = length(halfVector);
        if (halfLength > 0.001) {
            let glint = pow(max(dot(light.normal, halfVector / halfLength), 0.0), 40.0);
            result.colour += vec3f(1.0, 0.67, 0.32) * glint * effect * 0.16;
        }
    }
#endif
    return result;
}
