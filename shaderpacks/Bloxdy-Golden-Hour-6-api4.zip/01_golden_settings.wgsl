// Personal adaptation of the user-supplied Saphire V1.20 by rexlar.
// Saphire's wave field, water body, depth effects and lava remain the base.
// Golden Hour 6 keeps leaf UVs fixed and limits shadow brightness explicitly.
const GH_WIND: f32 = 1.0;
const GH_EXPOSURE: f32 = 1.16;
const GH_REFLECTION: f32 = 1.14;
const GH_ATMOSPHERE: f32 = 0.24;
// Explicit art direction paired with Custom Sky 6, not an inferred engine sun.
const GH_AUTHORED_SUN_WHEN_MISSING: bool = true;
