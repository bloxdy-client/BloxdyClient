// Use one continuous displacement field at shared leaf vertices. The stronger
// amplitude is deliberately visible at ordinary tree-viewing distances.
// Strict policy prohibits moving geometry; no scrolling-texture substitute.
fn ghLeafOffset(position: vec3f, time: f32) -> vec3f {
    let gust = 0.70 + 0.30 * sin(position.x * 0.12 + position.z * 0.09 + time * 0.65);
    let sway = sin(position.x * 0.54 + position.z * 0.38 + time * 1.9);
    let flutter = sin(position.y * 2.6 + position.x * 1.1 + time * 3.4);
    return vec3f(sway * 0.19, flutter * 0.022, sway * 0.11 + flutter * 0.025) * (gust * GH_WIND);
}

#ifndef BLOXD_STRICT
fn bloxdTerrainVertex(v: BloxdVertexIn) -> BloxdVertex {
    var output = bloxdDefaultVertex(v);
    if (ghLeaf(v.blockFlags)) {
        output.position = output.position + ghLeafOffset(ghWorld(v.position), ghTime());
    }
    return output;
}
#endif
