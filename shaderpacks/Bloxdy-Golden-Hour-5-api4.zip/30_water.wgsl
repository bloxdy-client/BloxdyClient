fn waterCurrents(p: vec2f, t: f32, dist: f32) -> vec3f {
    let near = 1.0 - smoothstep(40.0, 140.0, dist);
    if (near <= 0.001) { return vec3f(0.0); }
    let flow = orbitFlow(t, 16.0, 4.0, 8.0, 7.0);
    let w = vec2f(valueNoise(p * 0.045 + flow * 0.35), valueNoise(p * 0.045 - flow * 0.35 + vec2f(3.0, 7.0))) - 0.5;
    let n = valueNoise(p * 0.085 + w * 1.9 + flow * 0.25);
    let band = 1.0 - smoothstep(0.025, 0.2, abs(n - 0.5));
    let tint = mix(vec3f(0.04, 0.3, 0.42), vec3f(0.09, 0.5, 0.55), n * n);
    return tint * band * near;
}

fn ringLayer(wrapped: vec2f, cellBlocks: f32, salt: i32, chance: f32,
             every: f32, sizeMin: f32, sizeMax: f32) -> f32 {
    let cell = vec2i(floor(wrapped / cellBlocks));
    let h = hash3(vec3i(cell.x, salt, cell.y));
    if (h > chance) { return 0.0; }
    let h2 = hash3(vec3i(cell.x, salt + 7919, cell.y));
    let h3 = hash3(vec3i(cell.x, salt + 15485863, cell.y));
    let centre = (vec2f(0.3) + 0.4 * vec2f(h2, h3)) * cellBlocks;
    let here = wrapped - vec2f(cell) * cellBlocks;
    let age = fract(bloxdSeconds() / every + h3);
    let radius = mix(sizeMin, sizeMax, age);
    let ring = 1.0 - smoothstep(0.0, 0.35, abs(length(here - centre) - radius));
    return ring * (1.0 - age) * smoothstep(0.0, 0.1, age);
}

struct WaterShade {
    fresnel: f32,
    depth: f32,
    trans: vec3f,
    insc: vec3f,
    current: vec3f,
    cau: f32,
    foam: f32,
    whitecap: f32,
    ring: f32,
    crest: f32,
    glitter: f32,
    hot: bool,
    n: vec3f,
}
var<private> shade: WaterShade;

fn waterShade(s: BloxdSurfaceIn) -> WaterShade {
    var w: WaterShade;
    w.fresnel = 0.0;
    w.depth = 64.0;
    w.trans = vec3f(1.0);
    w.insc = vec3f(0.0);
    w.current = vec3f(0.0);
    w.cau = 0.0;
    w.foam = 0.0;
    w.whitecap = 0.0;
    w.ring = 0.0;
    w.crest = 0.0;
    w.glitter = 0.0;
    w.hot = false;
    w.n = s.normal;

    let t = packTime();
    let ph = loopPhase(t);
    let drift = vec2f(sin(ph * bloxdTau), cos(ph * bloxdTau));
    let worldPos = s.position + vec3f(bloxdRenderOffset());
    let upness = clamp(s.normal.y * 0.5 + 0.5, 0.0, 1.0);
    let sun = packSun();
    let day = dayAmount(sun);
    let power = smoothstep(-0.04, 0.16, sun.y);

    let toEye = bloxdEyePosition() - s.position;
    let dist = length(toEye);
    let viewDir = toEye / max(dist, 1e-4);

    var waveLod = WAVE_OCTAVES;
    if (dist > 80.0) { waveLod = 9; }
    if (dist > 160.0) { waveLod = 5; }

    let waveN = waveNormalDetail(worldPos.xz, t, waveLod);
    w.n = normalize(mix(s.normal, waveN, upness));

    let rippleFade = 1.0 - smoothstep(RIPPLE_FAR * 0.4, RIPPLE_FAR, dist);
    if (rippleFade > 0.001 && upness > 0.9) {
        let crawl = orbitFlow(t, RIPPLE_SPEED * 0.03, 41.0, RIPPLE_SPEED * 0.02, 67.0);
        let rp = (worldPos.xz - crawl) * RIPPLE_SCALE;
        let r0 = valueNoise(rp);
        let rx = valueNoise(rp + vec2f(0.06, 0.0));
        let rz = valueNoise(rp + vec2f(0.0, 0.06));
        let rsx = clamp((rx - r0) / 0.06 * RIPPLE_AMT, -1.5, 1.5);
        let rsz = clamp((rz - r0) / 0.06 * RIPPLE_AMT, -1.5, 1.5);
        w.n = normalize(w.n + vec3f(-rsx, 0.0, -rsz) * (rippleFade * upness * 0.65));
    }

    w.fresnel = fresnel(w.n, viewDir);
    w.crest = waveFieldLod(worldPos.xz, t, waveLod);

    let reflTest = reflect(-viewDir, w.n);
    let sparkleN = valueNoise(worldPos.xz * 7.0 + vec2f(cycPhase(t, 36.0), cycPhase(t, 57.0)) * 6.0);
    w.glitter = clamp(pow(max(dot(reflTest, sun), 0.0), 6.0) * step(0.75, sparkleN) * upness, 0.0, 1.0);

    var behindFound = false;
    var behindPos = vec3f(0.0);
    #ifdef BLOXD_SCENE_DEPTH
    let behind = bloxdOpaqueBehind();
    if (behind.hit) {
        behindFound = true;
        behindPos = behind.position;
        w.depth = max(behind.distance - dist, 0.0);
    }
    #endif

    #ifdef DEPTH_TINT
    w.trans = exp(-w.depth * WATER_ABSORB);
    let swell = 0.96 + 0.04 * sin(cycPhase(t, 311.0) + worldPos.x * 0.05 + worldPos.z * 0.03);
    w.insc = WATER_SCAT * ((1.0 - exp(-w.depth * 0.06)) * (0.30 + 0.70 * day)) * swell;
    #endif

    #ifdef WATER_CURRENTS
    #ifdef DEPTH_TINT
    w.current = waterCurrents(worldPos.xz, t, dist) * (1.0 - clamp(w.trans.g, 0.0, 1.0));
    #endif
    #endif

    #ifdef FLOOR_CAUSTICS
    #ifdef BLOXD_SCENE_DEPTH
    if (behindFound && power > 0.05 && w.depth < 30.0 && upness > 0.5) {
        let floorWorld = bloxdWorldPosition(behindPos);
        let pat = causticPattern(floorWorld.xz, t);
        let budget = power * cloudShadowCheap(floorWorld, sun, t)
            * exp(-w.depth * 0.13) * max(w.trans.r, 0.15);
        w.cau = pat * budget * CAUSTIC_GAIN;
    }
    #endif
    #endif

    #ifdef SHORE_FOAM
    let foamN = valueNoise(worldPos.xz * 2.5 + drift * 5.0) * 0.7
        + valueNoise(worldPos.xz * 9.0 - drift * 3.0) * 0.3;
    let edge = 1.0 - smoothstep(FOAM_SOLID, FOAM_WIDTH, w.depth);
    let recede = 0.75 + 0.25 * sin(cycPhase(t, 194.0) + w.depth * 3.0);
    w.foam = clamp(edge * step(0.5, upness) * (0.55 + 0.45 * foamN) * FOAM_STRENGTH * recede, 0.0, 1.0);
    #endif

    #ifdef WHITECAPS
    let breakN = valueNoise(worldPos.xz * 3.0 + drift * 7.0) * 0.45
        + valueNoise(worldPos.xz * 9.0 - drift * 11.0) * 0.25;
    let gravity = smoothstep(0.0, 1.0, clamp(1.0 - w.crest, 0.0, 1.0));
    w.whitecap = smoothstep(WHITECAP_START, 1.0, w.crest + breakN - gravity * 0.12)
        * upness * WHITECAP_STRENGTH;
    #endif

    #ifdef BUBBLE_RINGS
    if (upness > 0.5 && dist < RING_VISIBILITY) {
        let off = bloxdRenderOffset();
        let wrapped = s.position.xz + vec2f(f32(off.x % 4096), f32(off.z % 4096));
        let r1 = ringLayer(wrapped, RING_S_CELL, 11, RING_S_CHANCE, RING_S_EVERY, RING_S_MIN, RING_S_MAX);
        let r2 = ringLayer(wrapped, RING_M_CELL, 23, RING_M_CHANCE, RING_M_EVERY, RING_M_MIN, RING_M_MAX);
        let r3 = ringLayer(wrapped, RING_L_CELL, 37, RING_L_CHANCE, RING_L_EVERY, RING_L_MIN, RING_L_MAX);
        w.ring = clamp(r1 + r2 + r3, 0.0, 1.0);
    }
    #endif

    return w;
}

fn bloxdLiquidSurface(s: BloxdSurfaceIn) -> BloxdSurface {
    shade = waterShade(s);
    var o = bloxdDefaultSurface(s);

    if (isEmissiveFlags(s.blockFlags) || redDominant(s.colour)) {
        shade.hot = true;
        let worldPos = s.position + vec3f(bloxdRenderOffset() % vec3i(4096));
        let toEye = bloxdEyePosition() - s.position;
        let dist = max(length(toEye), 0.001);
        let ndv = clamp(dot(normalize(s.normal), toEye / dist), 0.0, 1.0);
        o.colour = LAVA_MARK;
        o.emission = lavaLook(faceTextureAxes(worldPos, s.normal), packTime(), ndv, dist);
        return o;
    }

    o.colour = WATER_MARK;
    return o;
}

fn bloxdLiquidLight(s: BloxdSurface, l: BloxdLightIn) -> BloxdLight {
    var o = bloxdDefaultLight(s, l);

    if (shade.hot || (1.0 - l.fogAlpha) < 0.02) { return o; }

    let sunDir = packSun();
    let day = dayAmount(sunDir);
    var c = l.litColour;

    let skyExposure = ghExposure(l);
    let sunVisibility = ghDirectVisibility(l);

    let worldPos = bloxdWorldPosition(l.position);
    let toEye = bloxdEyePosition() - l.position;
    let dist = max(length(toEye), 0.001);
    let viewDir = toEye / dist;

    let reflDir = reflect(-viewDir, shade.n);
    var reflSky = ghSky(reflDir);

    #ifdef CLOUD_REFLECTIONS
    let cp = worldPos.xz + reflDir.xz / max(reflDir.y, 0.1) * (CLOUD_BASE + 24.0);
    let ccW = cloudDensity(vec3f(cp.x, CLOUD_BASE + 24.0, cp.y), bloxdSeconds());
    let cloudCol = mix(vec3f(0.70, 0.74, 0.82), sunColour(sunDir), 0.35) * mix(0.3, 1.0, day);
    let farFade = 1.0 - smoothstep(40.0, 180.0, dist);
    reflSky = mix(reflSky, cloudCol, clamp(ccW, 0.0, 1.0) * CLOUD_REFLECT * farFade);
    #endif

    let reflectionHorizon = smoothstep(0.01, 0.18, reflDir.y);
    let indoorScatter = clamp(luminance(l.litColour) * 1.6, 0.0, 0.30);
    let waterIllumination = clamp(luminance(l.litColour) * 2.0 + skyExposure * 0.8, 0.0, 1.0);
    let reflMix = clamp(shade.fresnel * REFLECTIVITY * skyExposure * reflectionHorizon, 0.0, REFLECT_MAX);
    var reflected = mix(c, reflSky, reflMix);

    #ifdef DEPTH_TINT
    let deepBand = smoothstep(3.0, 12.0, shade.depth);
    let deepRefl = mix(shade.trans * shade.insc * 3.0 * waterIllumination, reflSky * 0.35 * skyExposure, 0.5);
    reflected = mix(reflected, deepRefl, deepBand * 0.3);
    #endif

    c = reflected;

    #ifdef DEPTH_TINT
    c = c * shade.trans;
    c = c + shade.insc * mix(indoorScatter, 1.0, skyExposure);
    #endif

    #ifdef WATER_CURRENTS
    c = c + shade.current * CURRENT_STRENGTH * mix(indoorScatter, 1.0, skyExposure);
    #endif

    #ifdef WATER_GLINTS
    if (hasSun(sunDir)) {
        let rs = max(dot(reflDir, sunDir), 0.0);
        let glint = ghSpecular(shade.n, viewDir, sunDir, 0.22);
        c = c + sunColour(sunDir) * (glint * 1.25 * sunVisibility);
        let crestSp = clamp(shade.crest, 0.0, 1.0) * pow(rs, 150.0);
        c = c + sunColour(sunDir) * (crestSp * CREST_SPARKLE * 0.20 * sunVisibility);
        c = c + sunColour(sunDir) * (shade.glitter * GLITTER * 0.30 * sunVisibility);
        let rm = max(dot(reflDir, -sunDir), 0.0);
        c = c + vec3f(0.65, 0.78, 1.0) * (pow(rm, 1400.0) * 3.5 * (1.0 - day) * skyExposure);
    }
    #endif

    #ifdef WATER_SSS
    let sssSun = select(0.0, 1.0, hasSun(sunDir));
    let sss = pow(max(dot(viewDir, -sunDir), 0.0), 3.0) * (0.5 + 0.5 * shade.crest);
    c = c + vec3f(0.08, 0.55, 0.45) * sunColour(sunDir) * (sss * SSS_STRENGTH * sssSun * sunVisibility);
    #endif

    let foamTotal = clamp(shade.foam + shade.whitecap, 0.0, 1.0);
    let foamWave = 0.8 + 0.2 * sin(bloxdTau * loopPhase(packTime()) * 30.0 + shade.crest * 2.0);
    let foamCol = vec3f(0.94, 0.98, 1.0) * max(luminance(c) * 1.6, 0.7 * waterIllumination);
    c = mix(c, foamCol, foamTotal * foamWave);

    #ifdef BUBBLE_RINGS
    let ringCol = vec3f(0.96, 0.99, 1.0) * max(luminance(c) * 1.4, 0.7 * waterIllumination);
    c = mix(c, ringCol, shade.ring);
    #endif

    #ifdef FLOOR_CAUSTICS
    c = c + sunColour(sunDir) * shade.cau * sunVisibility;
    #endif

    #ifdef GOD_RAYS
    #ifdef HAZE
    let gday = dayAmount(sunDir);
    if (gday > 0.05 && sunVisibility > 0.001) {
        let cosT = max(dot(viewDir, sunDir), 0.0);
        let sunsetF = 1.0 - smoothstep(0.10, 0.45, sunDir.y);
        let dh = bloxdEyePosition().y - l.position.y;
        let kdh = HAZE_FALLOFF * dh;
        let ratio = select(1.0, (1.0 - exp(-kdh)) / kdh, abs(kdh) > 0.001);
        var od = ((HAZE_DENSITY * dist) * exp(-HAZE_FALLOFF * max(bloxdEyePosition().y, 0.0))) * ratio;
        od = od + (HAZE_DENSITY * HAZE_GROUND * dist * smoothstep(0.0, 24.0, -dh));
        let hazeAmt = clamp((1.0 - exp(-od)) * (1.0 - l.fogAlpha) * HAZE_AMOUNT, 0.0, 0.85);
        let rays = rayPattern(viewDir, sunDir, packTime()) * pow(cosT, RAY_SUN_POWER) * hazeAmt
            * RAY_STRENGTH * (0.45 + 1.55 * sunsetF) * gday * sunVisibility;
        c = c + sunColour(sunDir) * rays;
    }
    #endif
    #endif

    o.colour = ghLiquidFinish(c, s, l);
    return o;
}
