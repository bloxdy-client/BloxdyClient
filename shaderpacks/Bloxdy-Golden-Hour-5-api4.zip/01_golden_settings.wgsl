// Personal adaptation of the user-supplied Saphire V1.20 by rexlar.
// Saphire's wave field, water body, depth effects and lava remain the base.
// Golden Hour 5 corrects sky/light leakage and overbright sun reflections.
const GH_WIND: f32 = 1.0;
const GH_EXPOSURE: f32 = 1.16;
const GH_REFLECTION: f32 = 0.78;
const GH_ATMOSPHERE: f32 = 0.24;
