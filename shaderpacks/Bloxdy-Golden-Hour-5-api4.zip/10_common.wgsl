fn ghTime() -> f32 {
    return bloxdSeconds();
}

fn ghHash(p: vec2f) -> f32 {
    var q = fract(vec3f(p.x, p.y, p.x) * vec3f(0.1031, 0.1030, 0.0973));
    q = q + vec3f(dot(q, q.yzx + vec3f(31.32)));
    return fract((q.x + q.y) * q.z);
}

fn ghNoise(p: vec2f) -> f32 {
    let cell = floor(p);
    let f = fract(p);
    let w = f * f * (3.0 - 2.0 * f);
    return mix(mix(ghHash(cell), ghHash(cell + vec2f(1.0, 0.0)), w.x),
        mix(ghHash(cell + vec2f(0.0, 1.0)), ghHash(cell + vec2f(1.0)), w.x), w.y);
}

fn ghWorld(p: vec3f) -> vec3f {
    // Keep patterns stationary across the engine's render-origin rebases.
    return bloxdWorldPosition(p);
}

fn ghSun() -> vec3f {
    let actual = bloxdSunDirection();
    if (dot(actual, actual) > 0.25) {
        return normalize(actual);
    }
    // Some worlds supply no directional sun. Use a stable low visual sun.
    return normalize(vec3f(0.86, 0.28, 0.43));
}

fn ghDay() -> f32 {
    return smoothstep(-0.12, 0.12, ghSun().y);
}

fn ghSunColour() -> vec3f {
    return mix(vec3f(0.27, 0.37, 0.62), vec3f(1.0, 0.62, 0.29), ghDay());
}

fn ghSky(direction: vec3f) -> vec3f {
    let day = ghDay();
    let up = clamp(direction.y, 0.0, 1.0);
    let horizon = mix(vec3f(0.025, 0.04, 0.075), vec3f(0.84, 0.49, 0.25), day);
    let zenith = mix(vec3f(0.008, 0.017, 0.045), vec3f(0.12, 0.30, 0.52), day);
    // A smooth environment lobe, not an unoccluded artificial sun disc or
    // moving cloud projection painted on every wall. Specular handles the sun.
    return mix(horizon, zenith, pow(up, 0.42));
}

fn ghLeaf(flags: u32) -> bool {
    return ((flags & bloxdBlockFlagVegetation) != 0u) && ((flags & bloxdBlockFlagDirt) == 0u);
}

fn ghExposure(l: BloxdLightIn) -> f32 {
#ifdef BLOXD_LIGHTING
    return ghVisibilityFromSky(l.skyLight).x;
#else
    // The unlit variant has no shelter data. Do not invent direct visibility.
    return 0.0;
#endif
}

fn ghDirectVisibility(l: BloxdLightIn) -> f32 {
#ifdef BLOXD_LIGHTING
    let actualSun = bloxdSunDirection();
    let hasSourceSun = select(0.0, 1.0, dot(actualSun, actualSun) > 0.25);
    return ghVisibilityFromSky(l.skyLight).y * hasSourceSun * ghDay();
#else
    return 0.0;
#endif
}

fn ghLamp(l: BloxdLightIn) -> f32 {
#ifdef BLOXD_LIGHTING
    let lamps = max(l.blockLight, l.heldLight);
    return smoothstep(0.08, 0.65, max(lamps.r, max(lamps.g, lamps.b)));
#else
    return 0.0;
#endif
}

fn ghSkyLevel(encoded: f32) -> f32 {
    // Inverse of Bloxd's cubic encoded skylight, as in the Saphire reference.
    let base = 1.0 - pow(max(1.0 - clamp(encoded, 0.0, 1.0), 0.0), 0.33333333);
    return 45.0 * base / max(1.0 + 2.0 * base, 0.001);
}

fn ghVisibilityFromSky(encoded: f32) -> vec2f {
    let level = ghSkyLevel(encoded);
    let environment = smoothstep(14.50, 14.97, level);
    let direct = smoothstep(14.65, 14.98, level);
    return vec2f(environment * environment, direct * direct);
}

fn ghRoughness(flags: u32) -> f32 {
    if (ghLeaf(flags)) { return 0.55; }
    if ((flags & bloxdBlockFlagDirt) != 0u) { return 0.48; }
    if ((flags & bloxdBlockFlagSand) != 0u) { return 0.52; }
    if ((flags & bloxdBlockFlagRock) != 0u) { return 0.34; }
    if ((flags & bloxdBlockFlagOpaque) == 0u) { return 0.23; }
    return 0.40;
}

fn ghSpecular(n: vec3f, v: vec3f, sun: vec3f, roughness: f32) -> f32 {
    let nv = max(dot(n, v), 0.0);
    let nl = max(dot(n, sun), 0.0);
    let halfVector = v + sun;
    if (nv < 0.001 || nl < 0.001 || dot(halfVector, halfVector) < 0.0001) {
        return 0.0;
    }
    let h = normalize(halfVector);
    let nh = max(dot(n, h), 0.0);
    let vh = max(dot(v, h), 0.0);
    let r = max(roughness, 0.20);
    let a = r * r;
    let a2 = a * a;
    let denominator = nh * nh * (a2 - 1.0) + 1.0;
    let distribution = a2 / max(3.14159265 * denominator * denominator, 0.000001);
    let k = (r + 1.0) * (r + 1.0) * 0.125;
    let geometry = (nv / (nv * (1.0 - k) + k)) * (nl / (nl * (1.0 - k) + k));
    let fresnel = 0.035 + 0.965 * pow(1.0 - vh, 5.0);
    return min(distribution * geometry * fresnel / max(4.0 * nv, 0.001), 1.25);
}

fn ghFresnel(normal: vec3f, view: vec3f) -> f32 {
    let cosine = clamp(dot(normal, view), 0.0, 1.0);
    return 0.02 + 0.98 * pow(1.0 - cosine, 5.0);
}

fn ghGrade(colour: vec3f) -> vec3f {
    let day = ghDay();
    let exposed = max(colour * GH_EXPOSURE, vec3f(0.0));
    let luma = dot(exposed, vec3f(0.2126, 0.7152, 0.0722));
    var result = mix(vec3f(luma), exposed, 1.09);
    let highlights = smoothstep(0.18, 0.85, luma);
    let shadeTint = mix(vec3f(0.70, 0.80, 1.08), vec3f(0.79, 0.88, 1.10), day);
    let sunTint = mix(vec3f(0.81, 0.91, 1.12), vec3f(1.17, 1.04, 0.80), day);
    result = result * mix(shadeTint, sunTint, highlights);
    // Filmic shoulder keeps the stronger key light and glints below clipping.
    let x = max(result, vec3f(0.0));
    let film = (x * (2.51 * x + vec3f(0.03))) / (x * (2.43 * x + vec3f(0.59)) + vec3f(0.14));
    return clamp(mix(x / (vec3f(1.0) + x * 0.24), film, 0.72), vec3f(0.0), vec3f(1.0));
}

fn ghAtmosphere(colour: vec3f, l: BloxdLightIn) -> vec3f {
    let dist = distance(bloxdEyePosition(), l.position);
    let visibility = ghExposure(l) * ghDirectVisibility(l);
    let haze = (1.0 - exp(-max(dist - 8.0, 0.0) * 0.007)) * visibility * GH_ATMOSPHERE;
    let viewRay = normalize(l.position - bloxdEyePosition() + vec3f(0.0, 0.00001, 0.0));
    let towardSun = pow(max(dot(viewRay, ghSun()), 0.0), 5.0);
    let atmosphereColour = mix(vec3f(0.36, 0.45, 0.57), vec3f(0.92, 0.61, 0.34), towardSun);
    return mix(colour, atmosphereColour, haze);
}

fn ghFinish(colour: vec3f, s: BloxdSurface, l: BloxdLightIn) -> vec3f {
    var result = ghGrade(colour + s.emission);
    result = ghAtmosphere(result, l);
    return bloxdApplyFog(result, l);
}

fn ghLiquidFinish(colour: vec3f, s: BloxdSurface, l: BloxdLightIn) -> vec3f {
    // Keep Saphire's water/lava response; replace only its ungated haze.
    return bloxdApplyFog(ghAtmosphere(softClip(colour + s.emission), l), l);
}
