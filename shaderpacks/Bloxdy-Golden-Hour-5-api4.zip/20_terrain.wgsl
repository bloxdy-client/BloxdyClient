fn bloxdTerrainSurface(s: BloxdSurfaceIn) -> BloxdSurface {
    var output = bloxdDefaultSurface(s);
    if (ghLeaf(s.blockFlags) && s.textureId != 0u) {
        // API-4 texture flutter also animates the interior of greedy-meshed
        // leaf faces, where moving just a few distant corners is hard to see.
        let p = ghWorld(s.position);
        let t = ghTime();
        let offset = vec2f(sin(p.x * 0.9 + p.y * 0.7 + t * 2.1),
            cos(p.z * 0.8 + p.y * 1.1 - t * 1.7)) * (0.045 * GH_WIND);
        let baseTexel = bloxdTexel(s.textureId, s.uv, s.mipLevel);
        let windTexel = bloxdTexel(s.textureId, s.uv + offset, s.mipLevel);
        let ratio = clamp(windTexel.rgb / max(baseTexel.rgb, vec3f(0.04)), vec3f(0.45), vec3f(1.8));
        output.colour = output.colour * ratio;
    }
    output.colour = output.colour * 0.96;
    return output;
}

fn bloxdTerrainLight(s: BloxdSurface, l: BloxdLightIn) -> BloxdLight {
    var output = bloxdDefaultLight(s, l);
    let normal = normalize(l.normal);
    let sun = ghSun();
    let day = ghDay();
    let outside = ghExposure(l);
    let visibleSun = ghDirectVisibility(l);
    let lamp = ghLamp(l);
    let sunFacing = max(dot(normal, sun), 0.0);
    var shade = 1.0;
#ifdef BLOXD_LIGHTING
    // Shape real engine skylight and occlusion; do not paint arbitrary tree
    // silhouettes. Keep interiors and lamps from receiving outdoor darkening.
    let skyLevel = ghSkyLevel(l.skyLight);
    let contact = smoothstep(13.75, 14.99, skyLevel);
    let canopy = clamp((1.0 - l.skyLight) / 0.0045, 0.0, 1.0)
        * smoothstep(0.48, 0.87, l.skyLight);
    shade = 1.0 - (1.0 - contact) * 0.38 * (1.0 - lamp) * day * outside;
    shade = shade * (1.0 - canopy * 0.28 * (1.0 - lamp) * day * outside);
#endif
    var colour = l.litColour;
    let emissive = (l.blockFlags & bloxdBlockFlagEmissive) != 0u;
    if (!emissive) {
        let keyLight = sunFacing * visibleSun;
        let coolFill = mix(vec3f(1.0), vec3f(0.67, 0.79, 1.04), outside * (1.0 - keyLight) * 0.65);
        colour = colour * coolFill * shade;
        colour = colour + s.colour * ghSunColour() * (0.36 * keyLight * shade);
        if (normal.y < -0.4) {
            colour = colour * 0.88;
        }
    }

    let toEye = bloxdEyePosition() - l.position;
    let dist = max(length(toEye), 0.001);
    let view = toEye / dist;
    // All materials remain glossy. Sky is only a valid environment in exposed
    // pixels and above the reflection horizon; it is never an interior image.
    let roughness = ghRoughness(l.blockFlags);
    let fresnel = ghFresnel(normal, view);
    let reflectedDirection = reflect(-view, normal);
    let skyWeight = outside * smoothstep(0.015, 0.25, reflectedDirection.y);
    let blurDirection = normalize(mix(reflectedDirection, vec3f(0.0, 1.0, 0.0), roughness * roughness * 0.45));
    let reflected = ghSky(blurDirection);
    let gloss = clamp((0.025 + fresnel * 0.66) * GH_REFLECTION * (1.0 - roughness * 0.45), 0.0, 0.56);
    colour = mix(colour, reflected, gloss * skyWeight);
    colour = colour * (1.0 - gloss * (1.0 - skyWeight) * 0.06);
    let glint = ghSpecular(normal, view, sun, roughness);
    colour = colour + ghSunColour() * (glint * visibleSun * GH_REFLECTION * 1.15);

    if (ghLeaf(l.blockFlags)) {
        let place = ghWorld(l.position);
        let flutter = sin(place.x * 1.8 + place.z * 0.9 + ghTime() * 2.2)
            * sin(place.y * 1.1 - ghTime() * 1.4);
        colour = colour * (1.0 + flutter * 0.095 * GH_WIND * outside);
        let backlight = pow(max(dot(-view, sun), 0.0), 3.0) * visibleSun;
        colour = colour + s.colour * vec3f(1.0, 0.80, 0.27) * backlight * 0.18;
    }
    output.colour = ghFinish(colour, s, l);
    return output;
}
