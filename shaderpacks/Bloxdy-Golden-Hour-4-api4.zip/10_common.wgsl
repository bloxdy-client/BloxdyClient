fn ghTime() -> f32 {
    return bloxdSeconds();
}

fn ghHash(p: vec2f) -> f32 {
    var q = fract(vec3f(p.x, p.y, p.x) * vec3f(0.1031, 0.1030, 0.0973));
    q = q + vec3f(dot(q, q.yzx + vec3f(31.32)));
    return fract((q.x + q.y) * q.z);
}

fn ghNoise(p: vec2f) -> f32 {
    let cell = floor(p);
    let f = fract(p);
    let w = f * f * (3.0 - 2.0 * f);
    return mix(mix(ghHash(cell), ghHash(cell + vec2f(1.0, 0.0)), w.x),
        mix(ghHash(cell + vec2f(0.0, 1.0)), ghHash(cell + vec2f(1.0)), w.x), w.y);
}

fn ghWorld(p: vec3f) -> vec3f {
    // Keep patterns stationary across the engine's render-origin rebases.
    return bloxdWorldPosition(p);
}

fn ghSun() -> vec3f {
    let actual = bloxdSunDirection();
    if (dot(actual, actual) > 0.25) {
        return normalize(actual);
    }
    // Some worlds supply no directional sun. Use a stable low visual sun.
    return normalize(vec3f(0.86, 0.28, 0.43));
}

fn ghDay() -> f32 {
    return smoothstep(-0.12, 0.12, ghSun().y);
}

fn ghSunColour() -> vec3f {
    return mix(vec3f(0.30, 0.42, 0.70), vec3f(1.0, 0.70, 0.37), ghDay());
}

fn ghSky(direction: vec3f) -> vec3f {
    let day = ghDay();
    let up = clamp(direction.y, 0.0, 1.0);
    let horizon = mix(vec3f(0.035, 0.055, 0.10), vec3f(0.96, 0.65, 0.37), day);
    let zenith = mix(vec3f(0.012, 0.022, 0.06), vec3f(0.22, 0.47, 0.72), day);
    var colour = mix(horizon, zenith, pow(up, 0.52));
    let sunDot = max(dot(direction, ghSun()), 0.0);
    colour = colour + ghSunColour() * (pow(sunDot, 22.0) * 0.18 + pow(sunDot, 1000.0) * 2.0);
    // This is an analytic sky reflection; no neighbouring scene pixels exist
    // in the API. Never invent reflected buildings or hidden world geometry.
    let cloudUv = direction.xz / max(direction.y + 0.18, 0.15) * 1.2;
    let drift = vec2f(ghTime() * 0.008, ghTime() * 0.003);
    let cloud = ghNoise(cloudUv + drift) * 0.68 + ghNoise(cloudUv * 2.7 + drift) * 0.32;
    let cloudMask = smoothstep(0.54, 0.73, cloud) * smoothstep(0.0, 0.20, direction.y);
    return mix(colour, mix(vec3f(0.09, 0.12, 0.18), vec3f(0.88, 0.77, 0.63), day), cloudMask * 0.62);
}

fn ghLeaf(flags: u32) -> bool {
    return ((flags & bloxdBlockFlagVegetation) != 0u) && ((flags & bloxdBlockFlagDirt) == 0u);
}

fn ghExposure(l: BloxdLightIn) -> f32 {
#ifdef BLOXD_LIGHTING
    return smoothstep(0.50, 0.98, l.skyLight);
#else
    return 1.0;
#endif
}

fn ghLamp(l: BloxdLightIn) -> f32 {
#ifdef BLOXD_LIGHTING
    let lamps = max(l.blockLight, l.heldLight);
    return smoothstep(0.08, 0.65, max(lamps.r, max(lamps.g, lamps.b)));
#else
    return 0.0;
#endif
}

fn ghSkyLevel(encoded: f32) -> f32 {
    // Inverse of Bloxd's cubic encoded skylight, as in the Saphire reference.
    let base = 1.0 - pow(max(1.0 - clamp(encoded, 0.0, 1.0), 0.0), 0.33333333);
    return 45.0 * base / max(1.0 + 2.0 * base, 0.001);
}

fn ghFresnel(normal: vec3f, view: vec3f) -> f32 {
    let cosine = clamp(dot(normal, view), 0.0, 1.0);
    return 0.02 + 0.98 * pow(1.0 - cosine, 5.0);
}

fn ghGrade(colour: vec3f) -> vec3f {
    let day = ghDay();
    let exposed = max(colour * GH_EXPOSURE, vec3f(0.0));
    let luma = dot(exposed, vec3f(0.2126, 0.7152, 0.0722));
    var result = mix(vec3f(luma), exposed, 1.08);
    let highlights = smoothstep(0.18, 0.85, luma);
    let shadeTint = mix(vec3f(0.73, 0.85, 1.14), vec3f(0.87, 0.94, 1.09), day);
    let sunTint = mix(vec3f(0.81, 0.91, 1.12), vec3f(1.16, 1.055, 0.84), day);
    result = result * mix(shadeTint, sunTint, highlights);
    // Keep white blocks recognisable and roll off glints rather than clipping.
    return max(result, vec3f(0.0)) / (vec3f(1.0) + max(result - 0.8, vec3f(0.0)) * 0.48);
}

fn ghFinish(colour: vec3f, s: BloxdSurface, l: BloxdLightIn) -> vec3f {
    var result = ghGrade(colour + s.emission);
    let dist = distance(bloxdEyePosition(), l.position);
    let haze = (1.0 - exp(-dist * 0.003)) * ghExposure(l) * ghDay() * 0.25;
    result = mix(result, vec3f(0.83, 0.65, 0.45), haze);
    return bloxdApplyFog(result, l);
}
