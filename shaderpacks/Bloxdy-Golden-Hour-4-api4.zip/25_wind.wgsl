#ifndef BLOXD_STRICT
#ifdef WAVY_WATER
fn bloxdLiquidVertex(v: BloxdVertexIn) -> BloxdVertex {
    var o = bloxdDefaultVertex(v);
    if ((v.blockFlags & bloxdBlockFlagEmissive) == 0u) {
        let worldPos = v.position + vec3f(bloxdRenderOffset());
        let h = waveField(worldPos.xz, packTime());
        o.position.y = o.position.y - WAVE_HEIGHT * (0.5 + 0.5 * h);
    }
    return o;
}
#endif
#endif