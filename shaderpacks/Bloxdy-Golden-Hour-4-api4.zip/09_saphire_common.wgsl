fn packTime() -> f32 {
    return bloxdSeconds() % 3600.0;
}

fn luminance(c: vec3f) -> f32 {
    return dot(c, LUMA);
}

fn hasSun(sunDir: vec3f) -> bool {
    return dot(sunDir, sunDir) > 0.25;
}

#ifdef CUSTOM_SKY_SUN
fn realSunMissing() -> bool {
    let s = bloxdSunDirection();
    return dot(s, s) <= 0.25;
}

fn fixedSunDir() -> vec3f {
    var e = 0.30;
    var moon = 1.0;
    #ifdef SKY_NOON
    e = 0.85;
    #endif
    #ifdef SKY_NIGHT
    e = -0.62;
    moon = -1.0;
    #endif
    let h = sqrt(max(1.0 - e * e, 0.0));
    var az = vec2f(1.0, 0.0);
    #ifdef SUN_FROM_MINUS_X
    az = vec2f(-1.0, 0.0);
    #endif
    #ifdef SUN_FROM_PLUS_Z
    az = vec2f(0.0, 1.0);
    #endif
    #ifdef SUN_FROM_MINUS_Z
    az = vec2f(0.0, -1.0);
    #endif
    return vec3f(az.x * h * moon, e, az.y * h * moon);
}

fn packSun() -> vec3f {
    #ifdef CUSTOM_SKY_SUN
    if (realSunMissing()) {
        return fixedSunDir();
    }
    #endif
    return bloxdSunDirection();
}
#else
fn packSun() -> vec3f {
    return bloxdSunDirection();
}
#endif

fn dayAmount(sunDir: vec3f) -> f32 {
    if (!hasSun(sunDir)) { return 1.0; }
    return smoothstep(-0.08, 0.18, sunDir.y);
}

fn goldenAmount(sunDir: vec3f) -> f32 {
    if (!hasSun(sunDir)) { return 0.0; }
    let e = sunDir.y;
    return smoothstep(-0.14, 0.02, e) * (1.0 - smoothstep(0.04, 0.45, e));
}

fn sunColour(sunDir: vec3f) -> vec3f {
    let day = dayAmount(sunDir);
    let golden = goldenAmount(sunDir);
    var c = SUN_TINT;
    c = mix(c, SUNSET_TINT, golden);
    c = mix(c, NIGHT_TINT * 0.4, 1.0 - day);
    return c * SUN_BRIGHTNESS;
}

fn rawSkyLevel(encoded: f32) -> f32 {
    let base = 1.0 - pow(max(1.0 - clamp(encoded, 0.0, 1.0), 0.0), 1.0 / 3.0);
    return 45.0 * base / max(1.0 + 2.0 * base, 0.0001);
}

fn contactShadow(l: BloxdLightIn) -> f32 {
    #ifdef BLOXD_LIGHTING
    let v = rawSkyLevel(clamp(l.skyLight, 0.0, 1.0));
    let e = min(fwidth(v) * 0.55, 0.40);
    return smoothstep(14.12 - e, 14.93 + e, v);
    #else
    return 1.0;
    #endif
}

#ifdef BLOXD_LIGHTING
fn torchLight(albedo: vec3f, l: BloxdLightIn, sy: f32, d: f32) -> vec3f {
    let bl = max(l.blockLight, l.heldLight);
    let y = luminance(bl);
    if (y < 0.003) { return vec3f(0.0); }
    let mx = max(bl.r, max(bl.g, bl.b));
    let sat = (mx - min(bl.r, min(bl.g, bl.b))) / max(mx, 0.001);
    let warm = mix(vec3f(1.0, 0.42, 0.14), vec3f(1.0, 0.8, 0.5), smoothstep(0.15, 0.85, y));
    let col = mix(warm, bl / max(mx, 0.001), smoothstep(0.2, 0.55, sat));
    let t = packTime();
    let fl = 1.0 + TORCH_FLICKER_AMT * (0.6 * sin(t * 7.3 + l.position.x * 0.9 + l.position.z * 1.3)
        + 0.4 * sin(t * 13.1 + l.position.y * 1.7));
    return albedo * col * (pow(y, 0.85) * TORCH_DIFFUSE * fl * (1.0 - 0.75 * sy * d))
        + col * (pow(y, 2.5) * TORCH_CORE * fl);
}
#endif

fn skyColour(dir: vec3f, sunDir: vec3f) -> vec3f {
    let day = dayAmount(sunDir);
    let golden = goldenAmount(sunDir);

    let zenith = mix(SKY_ZENITH_NIGHT, SKY_ZENITH_DAY, day);
    var horizon = mix(SKY_HORIZON_NIGHT, SKY_HORIZON_DAY, day);
    horizon = mix(horizon, SKY_HORIZON_GOLDEN, golden);

    let up = clamp(dir.y, 0.0, 1.0);
    var sky = mix(zenith, horizon, pow(1.0 - up, 3.0));

    let below = 1.0 - smoothstep(-0.35, 0.0, dir.y);
    sky = mix(sky, SKY_DEEP_COLOUR, below);

    if (hasSun(sunDir)) {
        let sunAmt = max(dot(dir, sunDir), 0.0);
        sky = sky + sunColour(sunDir) * ((pow(sunAmt, 6.0) * 0.22) + (pow(sunAmt, 48.0) * 0.45) + (pow(sunAmt, 1200.0) * 5.0)) * (0.35 + 0.65 * day);
        let moonAmt = max(dot(dir, -sunDir), 0.0);
        sky = sky + vec3f(0.7, 0.8, 1.0) * (pow(moonAmt, 1500.0) * 1.5 * (1.0 - day));
    }
    return sky;
}

fn hash3(b: vec3i) -> f32 {
    let u = bitcast<vec3u>(b);
    var n = (u.x * 73856093u) ^ (u.y * 19349663u) ^ (u.z * 83492791u);
    n = (n ^ (n >> 16u)) * 0x45d9f3bu;
    n = n ^ (n >> 16u);
    return f32(n & 0xffffu) / 65535.0;
}

fn hash2(p: vec2f) -> f32 {
    var p3 = fract(p.xyx * 0.1031);
    p3 = p3 + vec3f(dot(p3, p3.yzx + vec3f(33.33)));
    return fract((p3.x + p3.y) * p3.z);
}

fn valueNoise(p: vec2f) -> f32 {
    let i = floor(p);
    let f = fract(p);
    let w = f * f * (3.0 - 2.0 * f);
    let a = hash2(i);
    let b = hash2(i + vec2f(1.0, 0.0));
    let c = hash2(i + vec2f(0.0, 1.0));
    let d = hash2(i + vec2f(1.0, 1.0));
    return mix(mix(a, b, w.x), mix(c, d, w.x), w.y);
}

fn cloudNoise(p: vec2f) -> f32 {
    var total = 0.0;
    var amp = 0.5;
    var q = p;
    for (var i = 0; i < 4; i = i + 1) {
        total = total + valueNoise(q) * amp;
        q = q * 2.03 + vec2f(17.1, 9.7);
        amp = amp * 0.5;
    }
    return total;
}

fn loopPhase(t: f32) -> f32 {
    return fract(t / 3600.0);
}

fn cycPhase(t: f32, n: f32) -> f32 {
    return bloxdTau * fract(t / 3600.0 * n);
}

fn orbitFlow(t: f32, r1: f32, c1: f32, r2: f32, c2: f32) -> vec2f {
    let a1 = cycPhase(t, c1);
    let a2 = cycPhase(t, c2);
    return vec2f(cos(a1), sin(a1)) * r1 + vec2f(cos(a2), sin(a2)) * r2;
}

// Bubbling vents for hot blocks: a sparse grid of vent cells, each
// emitting an expanding molten ring plus a breathing glow dome.
// All phase counts are whole cycles per 3600 s clock wrap, so nothing
// pops when the clock loops. Returns (ring, glow).
fn ventPattern(pIn: vec2f, t: f32, cellScale: f32, chance: f32, cellOff: vec2f) -> vec2f {
    let q = pIn * cellScale + cellOff;
    let cell = floor(q);
    let pick = hash2(cell + vec2f(11.0, 3.0));
    if (pick > chance) { return vec2f(0.0); }
    let j = hash2(cell + vec2f(37.0, 91.0));
    let j2 = hash2(cell + vec2f(5.0, 71.0));
    let here = q - cell;
    let centre = vec2f(0.3) + 0.4 * vec2f(j2, j);
    let age = fract(t / 3600.0 * (500.0 + floor(j * 100.0)));   // 6.0-6.6 s period
    let radius = mix(0.10, 0.40, age);
    let ring = 1.0 - smoothstep(0.0, 0.09, abs(length(here - centre) - radius));
    let dc = here - centre;
    let dome = exp(-dot(dc, dc) * 16.0);
    let breathe = 0.6 + 0.4 * sin(bloxdTau * fract(t / 3600.0 * (60.0 + floor(j2 * 60.0))));
    let fade = (1.0 - age) * smoothstep(0.0, 0.12, age);
    return vec2f(ring * fade, dome * fade * breathe);
}

fn rayPattern(v: vec3f, sun: vec3f, t: f32) -> f32 {
    var side = cross(vec3f(0.0, 1.0, 0.0), sun);
    if (length(side) < 0.05) {
        side = vec3f(1.0, 0.0, 0.0);
    }
    side = normalize(side);
    let upA = cross(sun, side);
    let ang = atan2(dot(v, upA), dot(v, side));
    let drift1 = cycPhase(t, 30.0);
    let drift2 = cycPhase(t, 46.0);
    let drift3 = cycPhase(t, 71.0);
    let a = sin(ang * 9.0 + drift1) * 0.5
        + sin(ang * 17.0 - drift2 + 1.3) * 0.3
        + sin(ang * 31.0 + drift3 + 4.1) * 0.2;
    return smoothstep(0.05, 0.9, a * 0.5 + 0.5);
}

fn cloudDensity(p: vec3f, t: f32) -> f32 {
    let alt = p.y - CLOUD_BASE;
    if ((alt < -2.0) || (alt > 56.0)) { return 0.0; }
    let prof = (smoothstep(0.0, 18.0, alt) * (1.0 - smoothstep(34.0, 56.0, alt)));
    if (prof <= 0.002) { return 0.0; }

    let ph = loopPhase(t);
    let drift = vec2f(cos(ph * bloxdTau), sin(ph * bloxdTau)) * CLOUD_DRIFT_RADIUS;
    var q = (p.xz + drift) * CLOUD_SCALE;
    let w = valueNoise(q * 1.7 + vec2f(3.1, 8.2));
    q = q + (vec2f(w - 0.5, 0.5 - w) * 1.1);
    let n = valueNoise(q) * 0.55
        + valueNoise(q * 2.3 + vec2f(7.0, 3.0)) * 0.30
        + valueNoise(q * 5.1 + vec2f(2.0, 11.0)) * 0.15;
    let cov = smoothstep(CLOUD_LO, CLOUD_HI, n);
    return cov * prof;
}

fn cloudShadowMarch(p: vec3f, sun: vec3f, t: f32, day: f32) -> f32 {
    if (day < 0.02) { return 1.0; }
    if (p.y > CLOUD_TOP) { return 1.0; }
    if (p.y < -8.0) { return 1.0; }
    if (sun.y <= 0.02) { return 1.0; }

    var tEnter = (CLOUD_BASE - p.y) / sun.y;
    let tExit = (CLOUD_TOP - p.y) / sun.y;
    tEnter = max(tEnter, 0.0);
    if (tExit <= tEnter) { return 1.0; }

    let span = tExit - tEnter;
    let stepLen = max(span / f32(CLOUD_STEPS), 1.0);

    var trans = 1.0;
    for (var i = 0; i < CLOUD_STEPS; i = i + 1) {
        let h = p + sun * (tEnter + ((f32(i) + 0.5) * stepLen));
        let d = cloudDensity(h, t);
        if (d > 0.003) {
            trans = trans * exp(-((d * CLOUD_EXTINCT) * stepLen));
        }
        if (trans < 0.05) { break; }
    }
    return trans;
}

fn cloudShadowCheap(p: vec3f, sun: vec3f, t: f32) -> f32 {
    let tt = ((CLOUD_BASE + 16.0) - p.y) / max(sun.y, 0.25);
    if (tt < 0.0) { return 1.0; }
    let hit = vec3f(p.x + (sun.x * tt), CLOUD_BASE + 16.0, p.z + (sun.z * tt));
    let d = cloudDensity(hit, t);
    return exp(-d * 0.9);
}

fn cloudHit(origin: vec3f, dir: vec3f, t: f32) -> f32 {
    let midY = CLOUD_BASE + 24.0;
    let tt = (midY - origin.y) / select(0.1, dir.y, abs(dir.y) > 0.1);
    if (tt <= 0.0) { return 0.0; }
    let hit = vec3f(origin.x + (dir.x * tt), midY, origin.z + (dir.z * tt));
    return cloudDensity(hit, t);
}

fn hgPhase(cosTheta: f32) -> f32 {
    let g = HAZE_G;
    let g2 = g * g;
    let d = (1.0 + g2) - ((2.0 * g) * cosTheta);
    return (1.0 - g2) / (12.566 * d * sqrt(d));
}

fn causticPattern(xz: vec2f, t: f32) -> f32 {
    let p = xz * 0.85;
    let dph = cycPhase(t, 3.0);
    let w = valueNoise(p * 0.45 + vec2f(cos(dph), sin(dph)) * 40.0);
    let a = sin(p.x * 2.1 + cycPhase(t, 917.0) + w * 3.4);
    let b = sin(p.y * 1.8 - cycPhase(t, 688.0) + w * 3.1);
    let c = sin((p.x + p.y) * 1.25 + cycPhase(t, 487.0));
    let v = clamp(((a * b * c) * 0.5) + 0.5, 0.0, 1.0);
    return pow(v, 3.2);
}

fn faceTextureAxes(position: vec3f, normal: vec3f) -> vec2f {
    let a = abs(normal);
    if (a.y > 0.5) { return position.xz; }
    if (a.x > 0.5) { return position.zy; }
    return position.xy;
}

fn subtleSurfaceTexture(position: vec3f, normal: vec3f) -> f32 {
    let dist = distance(bloxdEyePosition(), position);
    let near = 1.0 - smoothstep(MICRO_TEXTURE_FAR * 0.55, MICRO_TEXTURE_FAR, dist);
    if (near <= 0.0) { return 1.0; }
    let worldPos = position + vec3f(bloxdRenderOffset() % vec3i(4096));
    let uv = faceTextureAxes(worldPos, normal);
    let base = valueNoise(uv * MICRO_TEXTURE_SCALE) * 0.65
        + valueNoise(uv * (MICRO_TEXTURE_SCALE * 2.15) + vec2f(17.1, 9.7)) * 0.35;
    let detailWeight = 1.0 - smoothstep(8.0, 18.0, dist);
    let detail = valueNoise(uv * MICRO_TEXTURE_DETAIL + vec2f(31.7, 5.2));
    let pattern = mix(base, detail, 0.28 * detailWeight);
    return 1.0 + (pattern - 0.5) * 2.0 * MICRO_TEXTURE_AMOUNT * near;
}

fn isEmissiveFlags(flags: u32) -> bool {
    return (flags & bloxdBlockFlagEmissive) != 0u;
}

fn isLeafFlags(flags: u32) -> bool {
    return ((flags & bloxdBlockFlagVegetation) != 0u)
        && ((flags & bloxdBlockFlagDirt) == 0u);
}

fn isGrassFlags(flags: u32) -> bool {
    return ((flags & bloxdBlockFlagVegetation) != 0u)
        && ((flags & bloxdBlockFlagDirt) != 0u);
}

fn isGlassLike(flags: u32) -> bool {
    return ((flags & bloxdBlockFlagOpaque) == 0u)
        && ((flags & bloxdBlockFlagEmissive) == 0u)
        && ((flags & bloxdBlockFlagVegetation) == 0u);
}

// ---- reflective ice & glass ----
fn isIceLike(c: vec3f) -> bool {
    // v3: ice carries the Opaque bit, so colour is the only separator.
    // Blue must strictly dominate red by 10% - this is what excludes
    // snow / white concrete / pale stone (there b == r). Brightness
    // floor keeps dark saturated blues (lapis) out. Known residual:
    // pale moonstone builds (accepted corpus-wide; no engine Ice flag).
    let hi = max(c.r, max(c.g, c.b));
    return (hi > 0.45) && (c.b > c.r * 1.10) && (c.b >= c.g);
}

// Schlick 1994 reflectance: R = R0 + (1-R0)(1-cos)^5.
// Base clamped >= 0 because pow() is undefined for negative bases in WGSL.
fn schlick(cosTheta: f32, f0: f32) -> f32 {
    let c = clamp(cosTheta, 0.0, 1.0);
    return f0 + (1.0 - f0) * pow(1.0 - c, 5.0);
}

// World-anchored frost tilt per ~5 cm cell, top faces only, so the
// frost pattern does not crawl when the camera moves. Sides stay smooth.
fn frostNormal(n0: vec3f, worldPos: vec3f, amount: f32) -> vec3f {
    if (n0.y < 0.5) { return n0; }
    let cell = floor(worldPos.xz * 20.0);
    let a = hash2(cell) * 6.2831;
    let bump = (hash2(cell + vec2f(7.0, 3.0)) - 0.5) * amount;
    return normalize(vec3f(cos(a) * bump, 1.0, sin(a) * bump));
}

fn redDominant(c: vec3f) -> bool {
    return c.r > 0.3 && c.r > c.b * 1.6 && c.r >= c.g * 0.9;
}

fn lavaLook(pIn: vec2f, t: f32, ndv: f32, dist: f32) -> vec3f {
    let near = 1.0 - smoothstep(12.0, 80.0, dist);

    let flowA = orbitFlow(t, 9.0, 3.0, 4.5, 5.0);
    let flowB = orbitFlow(t, 3.5, 8.0, 2.0, 11.0);
    let flowC = orbitFlow(t, 1.8, 13.0, 1.0, 17.0);

    let w1 = vec2f(valueNoise(pIn * 0.13 + flowA), valueNoise(pIn * 0.13 - flowA + vec2f(9.0, 4.0))) - 0.5;
    let p1 = pIn * 0.13 + w1 * 1.3 + flowA * 0.5;
    let w2 = vec2f(valueNoise(p1 * 1.7 + flowB), valueNoise(p1 * 1.7 - flowB + vec2f(5.0, 2.0))) - 0.5;
    let p = pIn * 0.19 + w1 * 0.8 + w2 * 1.5 + flowA * 0.35;

    let heat = cloudNoise(p);
    let heatSlow = cloudNoise(p * 0.55 + flowB * 0.4);
    // drifting plates: slow orbital drift migrates the crust so plate
    // boundaries and crack tints slowly reform over minutes
    let plateDrift = orbitFlow(t, 0.9, 53.0, 0.6, 97.0);
    let plateId = hash2(floor((pIn + w1 * 2.2 + plateDrift) * 0.32));

    let healPhase = 0.5 + 0.5 * sin(cycPhase(t, 294.0) + heatSlow * bloxdTau);
    let crackWidth = mix(0.30, 0.17, healPhase);

    let d1 = abs(heat - 0.46);
    let core = 1.0 - smoothstep(0.004, mix(0.10, 0.06, near), d1);
    let vein = 1.0 - smoothstep(0.01, mix(0.34, 0.26, near) * crackWidth * 1.6, d1);
    let cool = 1.0 - smoothstep(0.05, 0.48 * crackWidth * 2.2, d1);

    var fine = 0.0;
    var pores = 0.0;
    var spark = 0.0;
    if (near > 0.01) {
        let heat2 = cloudNoise(p * 1.6 + vec2f(5.0, 2.0) - flowA * 1.2);
        fine = (1.0 - smoothstep(0.02, 0.18, abs(heat2 - 0.45))) * near * 0.4;
        let p3 = valueNoise(p * 3.1 + flowC);
        pores = step(0.90, p3) * (1.0 - clamp(vein + fine, 0.0, 1.0)) * near;
        let sparkCell = floor((pIn + flowA * 0.4) * 1.8);
        let sparkR = hash2(sparkCell);
        let sparkJ = hash2(sparkCell + vec2f(37.0, 91.0));
        let sparkT = cycPhase(t, 47.0) + sparkJ * bloxdTau;
        spark = step(0.965, sparkR) * pow(0.5 + 0.5 * sin(sparkT), 6.0) * near * vein;
    }

    let net = clamp(vein + fine, 0.0, 1.0);
    let poreGlow = pores * smoothstep(0.35, 0.8, heat) * near;

    let pulse = 0.90 + 0.10 * sin(cycPhase(t, 630.0) + heat * 10.0 + pIn.x * 0.15 + pIn.y * 0.11);

    let crustBase = vec3f(0.075, 0.012, 0.002) * (0.6 + 0.55 * plateId) * mix(0.85, 1.0, healPhase);
    let emberCol = vec3f(0.40, 0.05, 0.007);
    let molten = mix(vec3f(0.98, 0.14, 0.008), vec3f(1.0, 0.58, 0.11), net * net);
    let hotCore = vec3f(1.0, 0.88, 0.45);

    var col = crustBase * (1.0 - pores * 0.7);
    col = mix(col, emberCol, cool * cool * 0.95);
    col = mix(col, molten, 0.15 + 0.85 * net);
    col = mix(col, hotCore, core * (0.6 + 0.4 * pulse));
    col = col * (1.0 - pores * 0.85);
    col = col + emberCol * poreGlow * 0.5;

    // bubbling vents: expanding molten rings + breathing glow domes,
    // brighter where the crust is already cracked
    let vents = ventPattern(pIn, t, 0.5, VENT_CHANCE, vec2f(0.0, 0.0));
    let ventNear = near * near;
    let ventMelt = mix(0.35, 1.1, net);
    col = mix(col, hotCore, clamp(vents.y * 0.9 * ventMelt * ventNear, 0.0, 1.0));
    col = col + vec3f(1.0, 0.62, 0.16) * (vents.x * 1.5 * ventNear);

    let far = smoothstep(70.0, 200.0, dist);
    col = mix(col, vec3f(0.45, 0.1, 0.015), far * 0.55);

    col = col + vec3f(1.0, 0.75, 0.3) * spark * 1.4;

    return col * pulse * (0.90 + 0.13 * (1.0 - ndv));
}

fn magmaLook(pIn: vec2f, t: f32) -> vec3f {
    let flow = orbitFlow(t, 7.0, 2.0, 4.0, 3.0);
    let w = vec2f(valueNoise(pIn * 0.20 + flow), valueNoise(pIn * 0.20 - flow + vec2f(7.0, 3.0))) - 0.5;
    let p = pIn * 0.30 + w * 2.6 + flow;
    let heat = cloudNoise(p);
    let d1 = abs(heat - 0.46);
    let core = 1.0 - smoothstep(0.003, 0.06, d1);
    let ridge = 1.0 - smoothstep(0.015, 0.20, d1);
    let heat2 = cloudNoise(p * 2.1 + vec2f(5.0, 2.0) - flow * 1.5);
    let ridge2 = (1.0 - smoothstep(0.02, 0.11, abs(heat2 - 0.45))) * 0.5;
    let net = clamp(ridge + ridge2, 0.0, 1.0);
    let plateId = hash2(floor(pIn * 0.42 + w * 1.5));
    let pores = step(0.88, valueNoise(pIn * 4.2 + flow * 0.3)) * (1.0 - net);
    let pulse = 0.92 + 0.08 * sin(cycPhase(t, 573.0) + heat * 9.0);
    let crust = vec3f(0.055, 0.008, 0.0015) * (0.75 + 0.45 * plateId);
    let molten = mix(vec3f(0.95, 0.12, 0.005), vec3f(1.0, 0.55, 0.11), net * net);
    let hotCore = vec3f(1.0, 0.8, 0.35);
    var col = mix(crust, molten, 0.12 + 0.88 * net);
    col = mix(col, hotCore, core * 0.8);
    col = col * (1.0 - pores * 0.8);
    // vents on their own cell salt (magma has no distance gate)
    let vents = ventPattern(pIn, t, 0.62, VENT_CHANCE * 0.7, vec2f(41.0, 17.0));
    col = mix(col, hotCore, clamp(vents.y * 0.7, 0.0, 1.0));
    col = col + vec3f(1.0, 0.55, 0.12) * (vents.x * 1.1);
    return col * pulse * 1.18;
}

fn waveFieldLod(p: vec2f, t: f32, maxOct: i32) -> f32 {
    let wp = t / 3600.0;
    var h = 0.0;
    var amp = 0.5;
    for (var i = 0; i < maxOct; i = i + 1) {
        let fi = f32(i);
        let dir = vec2f(cos(fi * 2.3999632), sin(fi * 2.3999632));
        let freq = pow(1.68, fi);
        let cycles = 140.0 + fi * 53.0;
        let phase = bloxdTau * fract(wp * cycles);
        h = h + sin(dot(p, dir) * freq * 0.35 + phase) * amp;
        let dcy = 13.0 + fi * 5.0;
        let drift = vec2f(sin(bloxdTau * fract(wp * dcy)), cos(bloxdTau * fract(wp * dcy)));
        h = h + (valueNoise(p * freq * 0.5 + drift * (2.0 + fi * 0.9)) - 0.5) * amp * 0.9;
        amp = amp * 0.62;
    }
    return h / 2.4;
}

fn waveField(p: vec2f, t: f32) -> f32 {
    return waveFieldLod(p, t, WAVE_OCTAVES);
}

fn waveNormalDetail(p: vec2f, t: f32, maxOct: i32) -> vec3f {
    let e = 0.06;
    let hC = waveFieldLod(p, t, maxOct);
    let hX = waveFieldLod(p + vec2f(e, 0.0), t, maxOct);
    let hZ = waveFieldLod(p + vec2f(0.0, e), t, maxOct);
    let hXZ = waveFieldLod(p + vec2f(e, e), t, maxOct);
    let hXX = waveFieldLod(p + vec2f(e * 2.0, 0.0), t, maxOct);
    let hZZ = waveFieldLod(p + vec2f(0.0, e * 2.0), t, maxOct);
    let sx = clamp((hX * 2.0 + hXX * 0.25 + hXZ * 0.5 - hC * 2.75) / e * WAVE_NORMAL_STRENGTH * WAVE_NORMAL_3TAP, -2.5, 2.5);
    let sz = clamp((hZ * 2.0 + hZZ * 0.25 + hXZ * 0.5 - hC * 2.75) / e * WAVE_NORMAL_STRENGTH * WAVE_NORMAL_3TAP, -2.5, 2.5);
    return normalize(vec3f(-sx, 1.0, -sz));
}

fn fresnel(n: vec3f, v: vec3f) -> f32 {
    let cosTheta = clamp(abs(dot(n, v)), 0.0, 1.0);
    return 0.02 + 0.98 * pow(1.0 - cosTheta, 5.0);
}

fn softClip(c: vec3f) -> vec3f {
    let knee = HIGHLIGHT_KNEE;
    let peak = max(c.r, max(c.g, c.b));
    if (peak <= knee) { return c; }
    let room = 1.0 - knee;
    let squeezed = knee + room * (1.0 - 1.0 / (1.0 + (peak - knee) / room));
    return c * (squeezed / peak);
}

fn gradeColour(c: vec3f, sunDir: vec3f) -> vec3f {
    var col = c * EXPOSURE;
    let y = luminance(col);

    // chroma-aware vibrance: dull pixels gain colour, vivid ones are
    // left nearly alone (Breeze brighten.wgsl idiom)
    let mx = max(col.r, max(col.g, col.b));
    let mn = min(col.r, min(col.g, col.b));
    let chroma = clamp(mx - mn, 0.0, 1.0);
    let satAmt = SATURATION + VIBRANCE * (1.0 - chroma);
    col = max(mix(vec3f(y), col, satAmt), vec3f(0.0));

    let tone = mix(SHADOW_TONE, HIGHLIGHT_TONE, smoothstep(0.0, 1.0, y));
    col = col * mix(vec3f(1.0), tone, SPLIT_TONING);

    let k = clamp(col, vec3f(0.0), vec3f(1.0));
    let curve = k * k * (3.0 - 2.0 * k);
    col = mix(col, curve, CONTRAST);

    let glow = smoothstep(GLOW_THRESHOLD, 1.2, luminance(col)) * GLOW_STRENGTH;
    col = col + col * GLOW_TINT * glow;

    let night = (1.0 - dayAmount(sunDir)) * NIGHT_SHIFT_AMOUNT;
    col = mix(col, vec3f(luminance(col)) * NIGHT_TINT, night);

    return col;
}

fn finishColour(c: vec3f, s: BloxdSurface, l: BloxdLightIn) -> vec3f {
    var col = softClip(c + s.emission);
    let sun = packSun();
    let day = dayAmount(sun);

    #ifdef HAZE
    let eye = bloxdEyePosition();
    let seg = l.position - eye;
    let dist = max(length(seg), 0.001);
    let vdir = seg / dist;

    let dh = eye.y - l.position.y;
    let kdh = HAZE_FALLOFF * dh;
    let ratio = select(1.0, (1.0 - exp(-kdh)) / kdh, abs(kdh) > 0.001);
    var od = ((HAZE_DENSITY * dist) * exp(-HAZE_FALLOFF * max(eye.y, 0.0))) * ratio;
    od = od + (HAZE_DENSITY * HAZE_GROUND * dist * smoothstep(0.0, 24.0, -dh));

    var fogW = (1.0 - exp(-od)) * (1.0 - l.fogAlpha) * HAZE_AMOUNT;
    fogW = clamp(fogW, 0.0, 0.85);
    if (fogW > 0.001) {
        var base = select(vec3f(0.66, 0.74, 0.86), l.fogColour, length(l.fogColour) > 0.05);
        base = mix(base, vec3f(luminance(base)), 0.30);
        let cosT = max(dot(vdir, sun), 0.0);
        let mie = hgPhase(cosT);
        var hazeCol = mix(base, sunColour(sun), clamp(mie * 0.55, 0.0, 0.85));
        hazeCol = mix(hazeCol, sunColour(sun) * vec3f(1.02, 0.82, 0.66), goldenAmount(sun) * 0.22 * smoothstep(0.0, 1.0, cosT));
        hazeCol = hazeCol * day;
        #ifdef CLOUD_SHADOWS
        let hit = cloudHit(eye, vdir, bloxdSeconds());
        hazeCol = hazeCol * mix(1.06, 0.78, clamp(hit, 0.0, 1.0));
        #endif
        col = mix(col, hazeCol, fogW);
        col = col + sunColour(sun) * ((mie * 0.05) * fogW * day);
    }
    #endif

    #ifdef ANTI_BANDING
    let wpD = bloxdWorldPosition(l.position);
    let wpi = vec3i(floor(wpD)) % vec3i(4096);
    let qD = vec2f(f32(wpi.x) + f32(wpi.y) * 1.7, f32(wpi.z) - f32(wpi.y) * 0.9) * 61.0;
    col = col + vec3f((hash2(qD) - 0.5) * (1.5 / 255.0));
    #endif

    return mix(l.fogColour, col, (1.0 - l.fogAlpha));
}

fn oreSpeck(c: vec3f) -> f32 {
    let hi = max(c.r, max(c.g, c.b));
    let lo = min(c.r, min(c.g, c.b));
    let sat = (hi - lo) / max(hi, 0.001);
    let vivid = smoothstep(0.55, 0.8, hi) * smoothstep(0.28, 0.48, sat);
    let white = smoothstep(0.8, 0.95, lo);
    return max(vivid, white * 0.8);
}

fn leafColour(pick: u32) -> vec3f {
    switch pick {
        case 0u: { return vec3f(0.36, 0.62, 0.16); }
        case 1u: { return vec3f(0.50, 0.72, 0.20); }
        case 2u: { return vec3f(0.72, 0.78, 0.22); }
        case 3u: { return vec3f(0.88, 0.62, 0.18); }
        default: { return vec3f(0.80, 0.38, 0.14); }
    }
}

fn withFallingLeaves(colour: vec3f, position: vec3f, nearTree: bool) -> vec3f {
    if (!nearTree) { return colour; }
    let eye = bloxdEyePosition();
    let toSurface = position - eye;
    let surfaceDistance = length(toSurface);
    if (surfaceDistance > LEAF_RANGE) { return colour; }
    let d = toSurface / max(surfaceDistance, 0.001);
    let t = packTime();
    let fall = t * LEAF_FALL;
    var across = cross(d, vec3f(0.0, 1.0, 0.0));
    if (dot(across, across) < 0.0001) { across = vec3f(1.0, 0.0, 0.0); }
    across = normalize(across);
    let along = cross(d, across);
    let origin = vec3f(bloxdRenderOffset() % vec3i(3072));
    let stride = LEAF_RANGE / f32(LEAF_STEPS);

    for (var i = 0; i < LEAF_STEPS; i = i + 1) {
        let sliding = eye + origin + d * ((f32(i) + 0.5) * stride) + vec3f(0.0, fall, 0.0);
        let cell = vec3i(floor(sliding / LEAF_CELL));
        let h1 = hash3(cell + vec3i(0, 0, 7919));
        if (h1 > LEAF_CHANCE) { continue; }
        let h2 = hash3(cell + vec3i(104729, 0, 0));
        let h3 = hash3(cell + vec3i(0, 104729, 0));
        let h4 = hash3(cell + vec3i(7919, 15485863, 0));
        let phase = h4 * bloxdTau;
        let inCell = 0.25 + 0.5 * vec3f(h2, h3, hash3(cell + vec3i(13, 7, 104729)));
        let swayP = cycPhase(t, 745.0);
        let swayF = cycPhase(t, 516.0);
        let sway = vec3f(sin(swayP + phase) * 0.35, 0.0, cos(swayF + phase * 1.7) * 0.35);
        let leaf = (vec3f(cell) + inCell) * LEAF_CELL - vec3f(0.0, fall, 0.0) + sway - origin;

        let offset = leaf - eye;
        let depth = dot(offset, d);
        if (depth < 0.3 || depth > surfaceDistance - 0.05) { continue; }
        let off = offset - d * depth;
        var onLeaf = vec2f(dot(off, across), dot(off, along));
        let spin = cycPhase(t, 1262.0) + phase;
        onLeaf = vec2f(cos(spin) * onLeaf.x - sin(spin) * onLeaf.y,
                       sin(spin) * onLeaf.x + cos(spin) * onLeaf.y);
        let flip = max(abs(cos(spin * 1.73 + phase * 2.3)), 0.25);
        if (abs(onLeaf.x) < LEAF_SIZE * flip && abs(onLeaf.y) < LEAF_SIZE) {
            let sun = packSun();
            let lightLevel = mix(0.45, 1.05, smoothstep(0.0, 0.2, sun.y)) * mix(0.85, 1.1, h3);
            return leafColour(u32(h2 * 65535.0) % 5u) * lightLevel;
        }
    }
    return colour;
}

fn emberColour(pick: u32) -> vec3f {
    switch pick {
        case 0u: { return vec3f(1.0, 0.62, 0.15); }
        case 1u: { return vec3f(1.0, 0.45, 0.08); }
        case 2u: { return vec3f(1.0, 0.78, 0.30); }
        default: { return vec3f(0.95, 0.30, 0.05); }
    }
}

// Rising ember particles over hot blocks, drawn in front of the shaded
// pixel. Same screen-space march as the falling leaves, inverted: each
// pixel looks along the eye-to-pixel ray through 3D cells that slide
// DOWN over time, so the hashed embers move UP in the world. Gate: the
// pixel itself is a hot block (the leaf doctrine - the API exposes no
// neighbourhood, so embers only appear over visible lava/magma).
fn withEmbers(colour: vec3f, position: vec3f, nearHot: bool) -> vec3f {
    if (!nearHot) { return colour; }
    let eye = bloxdEyePosition();
    let toSurface = position - eye;
    let surfaceDistance = length(toSurface);
    if (surfaceDistance > EMBER_RANGE) { return colour; }
    let d = toSurface / max(surfaceDistance, 0.001);
    let t = packTime();
    let rise = t * EMBER_RISE;
    let origin = vec3f(bloxdRenderOffset() % vec3i(3072));
    let stride = EMBER_RANGE / f32(EMBER_STEPS);

    for (var i = 0; i < EMBER_STEPS; i = i + 1) {
        let sliding = eye + origin + d * ((f32(i) + 0.5) * stride) - vec3f(0.0, rise, 0.0);
        let cell = vec3i(floor(sliding / EMBER_CELL));
        let h1 = hash3(cell + vec3i(0, 0, 15489));
        if (h1 > EMBER_CHANCE) { continue; }
        let h2 = hash3(cell + vec3i(104729, 0, 0));
        let h3 = hash3(cell + vec3i(0, 104729, 0));
        let h4 = hash3(cell + vec3i(7919, 15485863, 0));
        let phase = h4 * bloxdTau;
        let inCell = 0.2 + 0.6 * vec3f(h2, h3, hash3(cell + vec3i(13, 7, 104729)));
        let swayP = cycPhase(t, 811.0);
        let swayF = cycPhase(t, 577.0);
        let sway = vec3f(sin(swayP + phase) * 0.25, 0.0, cos(swayF + phase * 1.4) * 0.25);
        let ember = (vec3f(cell) + inCell) * EMBER_CELL + vec3f(0.0, rise, 0.0) + sway - origin;

        let offset = ember - eye;
        let depth = dot(offset, d);
        if (depth < 0.3 || depth > surfaceDistance - 0.05) { continue; }
        let off = offset - d * depth;
        let pr = EMBER_SIZE * (0.7 + 0.6 * h3);
        // soft round glow: embers are light, not leaves
        let glow = clamp(1.0 - dot(off, off) / (pr * pr), 0.0, 1.0);
        if (glow > 0.0) {
            let flicker = 0.65 + 0.35 * sin(cycPhase(t, 1583.0) + phase * 3.0);
            let sun = packSun();
            let lightLevel = mix(0.6, 1.3, smoothstep(0.0, 0.25, sun.y)) * mix(0.7, 1.2, h2);
            return colour + emberColour(u32(h2 * 65535.0) % 4u) * (glow * glow * flicker * lightLevel);
        }
    }
    return colour;
}