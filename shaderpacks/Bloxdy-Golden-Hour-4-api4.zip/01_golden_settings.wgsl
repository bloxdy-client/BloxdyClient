// Personal adaptation of the user-supplied Saphire V1.20 by rexlar.
// 00_settings, 09_saphire_common, 25_wind and 30_water are unchanged
// Saphire sources, keeping water/lava dependencies and parameters identical.
// Golden Hour applies its grading and all-face gloss to terrain only.
const GH_WIND: f32 = 1.0;
const GH_EXPOSURE: f32 = 1.08;
const GH_REFLECTION: f32 = 1.0;
