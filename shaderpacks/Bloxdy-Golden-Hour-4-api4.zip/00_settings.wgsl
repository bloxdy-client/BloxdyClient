#define SUN_LIGHTING
#define FAKE_SHADOWS
#define CANOPY_SHADE
#define LEAF_SHIMMER
#define FALLING_LEAVES
#define CLOUD_SHADOWS
#define CLOUD_REFLECTIONS
#define GOD_RAYS
#define WAVY_WATER
#define WATER_GLINTS
#define WATER_SSS
#define WATER_CURRENTS
#define SHORE_FOAM
#define WHITECAPS
#define DEPTH_TINT
#define FLOOR_CAUSTICS
#define HAZE
#define GLOWING_ORES
#define BUBBLE_RINGS
#define BLOCK_VARIATION
#define TERRAIN_SPECULAR
#define SKY_TINT
#define RIM_LIGHT
#define MICRO_TEXTURE
#define CONTACT_SHADOWS
#define TORCH_FLICKER
#define ANTI_BANDING
#define PRESET_FILMIC
#define LONG_SHADOWS
#define CUSTOM_SKY_SUN
#define HD_SHADOWS
#define REFLECTIVE_SURFACES
#define ICY_REFLECTIONS
#define EMBERS

const EXPOSURE: f32 = 1.05;
const SATURATION: f32 = 1.42;
const VIBRANCE: f32 = 0.35;
const CONTRAST: f32 = 0.22;
const SPLIT_TONING: f32 = 0.45;
const SHADOW_TONE: vec3f = vec3f(0.78, 0.92, 1.3);
const HIGHLIGHT_TONE: vec3f = vec3f(0.95, 1.0, 1.1);
const GLOW_THRESHOLD: f32 = 0.82;
const GLOW_STRENGTH: f32 = 0.3;
const GLOW_TINT: vec3f = vec3f(0.85, 0.95, 1.1);
const HIGHLIGHT_KNEE: f32 = 0.85;
const FILMIC_STRENGTH: f32 = 0.3;
const GOLDEN_AMBIENT: f32 = 0.25;
const SUN_BOUNCE: f32 = 0.06;

const SUN_TINT: vec3f = vec3f(0.95, 0.9, 0.85);
const SUNSET_TINT: vec3f = vec3f(1.0, 0.55, 0.35);
const SUN_BRIGHTNESS: f32 = 1.2;
const SUN_KEY: f32 = 0.45;
const SHADOW_COLOUR: vec3f = vec3f(0.38, 0.44, 0.72);
const NIGHT_TINT: vec3f = vec3f(0.52, 0.7, 1.2);
const NIGHT_SHIFT_AMOUNT: f32 = 0.65;
const SHADOW_STRENGTH: f32 = 1.0;
const SHADOW_AO: f32 = 0.25;
const SHADOW_LONG: f32 = 3.0;
const PENUMBRA_SCALE: f32 = 0.55;
const PENUMBRA_MAX: f32 = 0.45;
const SHADE_DEPTH_RANGE: f32 = 3.0;
const SHADOW_DEEP: vec3f = vec3f(0.80, 0.85, 1.05);
const SHADOW_DEEP_AMT: f32 = 0.7;

const RAY_STRENGTH: f32 = 0.45;
const RAY_SUN_POWER: f32 = 4.0;

const CANOPY_SPREAD: f32 = 0.0035;
const CANOPY_STRENGTH: f32 = 0.7;
const CANOPY_TINT: vec3f = vec3f(0.55, 0.66, 0.5);
const LEAF_SHIMMER_AMT: f32 = 0.12;

const LEAF_RANGE: f32 = 10.0;
const LEAF_STEPS: i32 = 6;
const LEAF_CELL: f32 = 3.0;
const LEAF_CHANCE: f32 = 0.3;
const LEAF_SIZE: f32 = 0.09;
const LEAF_FALL: f32 = 0.6;

// ---- rising embers over hot blocks ----
const EMBER_RANGE: f32 = 12.0;    // how far embers are drawn (blocks)
const EMBER_STEPS: i32 = 6;       // march samples (cost: hot pixels only)
const EMBER_CELL: f32 = 2.5;      // ember lattice cell size (blocks)
const EMBER_CHANCE: f32 = 0.12;   // share of cells holding an ember
const EMBER_RISE: f32 = 0.9;      // rise speed (blocks/second)
const EMBER_SIZE: f32 = 0.10;     // ember glow radius (blocks)

const CLOUD_BASE: f32 = 96.0;
const CLOUD_TOP: f32 = 152.0;
const CLOUD_SCALE: f32 = 0.006;
const CLOUD_LO: f32 = 0.46;
const CLOUD_HI: f32 = 0.64;
const CLOUD_STEPS: i32 = 8;
const CLOUD_EXTINCT: f32 = 0.055;
const CLOUD_MARCH_LOD: f32 = 120.0;
const CLOUD_SHADOW_STRENGTH: f32 = 1.0;
const CLOUD_MIN_LIGHT: f32 = 0.30;
const CLOUD_DRIFT_RADIUS: f32 = 260.0;
const CLOUD_CYCLES: f32 = 2.0;
const CLOUD_REFLECT: f32 = 0.6;

const HAZE_DENSITY: f32 = 0.010;
const HAZE_FALLOFF: f32 = 0.030;
const HAZE_GROUND: f32 = 0.55;
const HAZE_G: f32 = 0.72;
const HAZE_AMOUNT: f32 = 0.6;

const WATER_ABSORB: vec3f = vec3f(0.42, 0.16, 0.08);
const WATER_SCAT: vec3f = vec3f(0.08, 0.38, 0.48);
const CAUSTIC_GAIN: f32 = 0.95;

const ORE_BY_COLOUR = true;
const ORE_INTENSITY: f32 = 0.85;
const ORE_WHOLE_BLOCK: f32 = 0.22;
const ORE_RANGE: f32 = 72.0;

const RING_VISIBILITY: f32 = 48.0;
const RING_S_CELL: f32 = 3.0;
const RING_S_CHANCE: f32 = 0.018;
const RING_S_EVERY: f32 = 3.5;
const RING_S_MIN: f32 = 0.7;
const RING_S_MAX: f32 = 1.3;
const RING_M_CELL: f32 = 5.0;
const RING_M_CHANCE: f32 = 0.016;
const RING_M_EVERY: f32 = 4.5;
const RING_M_MIN: f32 = 1.5;
const RING_M_MAX: f32 = 2.4;
const RING_L_CELL: f32 = 8.0;
const RING_L_CHANCE: f32 = 0.015;
const RING_L_EVERY: f32 = 6.0;
const RING_L_MIN: f32 = 2.6;
const RING_L_MAX: f32 = 4.2;

const MICRO_TEXTURE_AMOUNT: f32 = 0.35;
const MICRO_TEXTURE_SCALE: f32 = 6.0;
const MICRO_TEXTURE_DETAIL: f32 = 26.0;
const MICRO_TEXTURE_FAR: f32 = 26.0;

const CONTACT_STRENGTH: f32 = 0.85;

const TORCH_FLICKER_AMT: f32 = 0.12;
const TORCH_DIFFUSE: f32 = 0.55;
const TORCH_CORE: f32 = 0.4;

const RIPPLE_SCALE: f32 = 4.5;
const RIPPLE_AMT: f32 = 0.9;
const RIPPLE_FAR: f32 = 55.0;
const RIPPLE_SPEED: f32 = 40.0;
const CREST_SPARKLE: f32 = 1.6;
const RIM_STRENGTH: f32 = 0.35;

// ---- reflective ice & glass ----
// Mirror doctrine (Mango lava, applied to reflection): the surface stage
// crushes ice albedo to ICE_MARK, the light stage mirrors the sky on top.
const ICE_MARK: vec3f = vec3f(0.05, 0.07, 0.09);  // crushed ice albedo (slightly blue)
const ICE_MIRROR: f32 = 0.5;      // base mirror floor; 0.7 = almost full mirror face-on
const GLASS_REFLECT: f32 = 0.85;  // strength on the Schlick curve (max useful 1.0)
const ICE_REFLECT: f32 = 0.55;    // extra mirror as the view goes grazing
const ICE_FROST: f32 = 0.0;       // 0 = perfect mirror, 0.45 = frosted cells
const ICE_SPEC: f32 = 0.9;        // ice sun glint strength
const ICE_F0: f32 = 0.018;        // Schlick R0 for ice (n = 1.31)
const GLASS_F0: f32 = 0.043;      // Schlick R0 for glass (n = 1.52)

// ---- lava vents ----
const VENT_CHANCE: f32 = 0.20;    // share of crust cells with a bubbling vent

const LAVA_MARK: vec3f = vec3f(0.02, 0.004, 0.0);
const WATER_MARK: vec3f = vec3f(0.012, 0.035, 0.05);
const CURRENT_STRENGTH: f32 = 0.5;

const SKY_ZENITH_DAY: vec3f = vec3f(0.14, 0.4, 0.92);
const SKY_HORIZON_DAY: vec3f = vec3f(0.62, 0.82, 1.0);
const SKY_ZENITH_NIGHT: vec3f = vec3f(0.015, 0.03, 0.08);
const SKY_HORIZON_NIGHT: vec3f = vec3f(0.07, 0.1, 0.2);
const SKY_HORIZON_GOLDEN: vec3f = vec3f(1.0, 0.5, 0.22);
const SKY_DEEP_COLOUR: vec3f = vec3f(0.03, 0.11, 0.16);

const VARIATION_AMOUNT: f32 = 0.06;

const TERRAIN_GLOSS_STRENGTH: f32 = 0.22;
const SKY_TINT_STRENGTH: f32 = 0.14;

const WATER_CLARITY: f32 = 0.55;
const WAVE_OCTAVES: i32 = 14;
const WAVE_HEIGHT: f32 = 0.18;
const WAVE_NORMAL_STRENGTH: f32 = 2.8;
const WAVE_NORMAL_3TAP: f32 = 1.0;
const REFLECTIVITY: f32 = 0.92;
const REFLECT_MAX: f32 = 0.97;
const SUN_GLINT: f32 = 2.2;
const GLITTER: f32 = 1.1;
const SSS_STRENGTH: f32 = 1.5;
const WHITECAP_START: f32 = 0.55;
const WHITECAP_STRENGTH: f32 = 1.0;
const FOAM_SOLID: f32 = 0.03;
const FOAM_WIDTH: f32 = 0.55;
const FOAM_STRENGTH: f32 = 1.0;

const LUMA: vec3f = vec3f(0.2126, 0.7152, 0.0722);