// Bloxd shader-pack API 4. Independent pack, no client mod required.
// API usage and the encoded skylight curve were studied against the supplied
// Saphire V1.20 by rexlar. The effects below are implemented for Golden Hour.
// Rain is a local visual sunshower, not server weather. No weather API exists.
const GH_RAIN: f32 = 0.72;
const GH_WETNESS: f32 = 0.90;
const GH_PUDDLE_COVERAGE: f32 = 0.46;
const GH_WIND: f32 = 1.0;
const GH_RAIN_SAMPLES: i32 = 8;
const GH_RAIN_RANGE: f32 = 17.0;
const GH_WATER_HEIGHT: f32 = 0.070;
const GH_EXPOSURE: f32 = 1.08;
const GH_PI: f32 = 3.14159265;
