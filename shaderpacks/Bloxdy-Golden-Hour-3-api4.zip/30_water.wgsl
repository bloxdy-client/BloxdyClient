// Per-fragment state carries geometric depth and wave normals between hooks.
// Lava keeps the engine's material rather than being mistaken for water.
var<private> ghLiquidHot: bool;
var<private> ghLiquidNormal: vec3f;
var<private> ghLiquidDepth: f32;
var<private> ghLiquidFoam: f32;
var<private> ghLiquidRipple: f32;
var<private> ghLiquidFloor: vec3f;
var<private> ghLiquidFloorFound: bool;

fn bloxdLiquidSurface(s: BloxdSurfaceIn) -> BloxdSurface {
    var output = bloxdDefaultSurface(s);
    ghLiquidHot = ((s.blockFlags & bloxdBlockFlagEmissive) != 0u)
        || (s.colour.r > 0.35 && s.colour.r > s.colour.b * 1.8 && s.colour.r > s.colour.g * 1.25);
    ghLiquidNormal = s.normal;
    ghLiquidDepth = 5.0;
    ghLiquidFoam = 0.0;
    ghLiquidRipple = 0.0;
    ghLiquidFloor = vec3f(0.0);
    ghLiquidFloorFound = false;
    if (ghLiquidHot) {
        return output;
    }
    let toEye = bloxdEyePosition() - s.position;
    let dist = max(length(toEye), 0.001);
    let view = toEye / dist;
    let top = smoothstep(0.3, 0.95, s.normal.y);
    let world = ghWorld(s.position);
    let waves = ghWaves(world.xz, ghTime());
    let detailFade = 1.0 - smoothstep(30.0, 80.0, dist);
    var slope = waves.yz * 2.2;
    if (dist < 38.0) {
        let ripples = ghRipple(world.xz, ghTime());
        slope = slope + ripples.xy * detailFade;
        ghLiquidRipple = max(ripples.z, 0.0) * detailFade;
    }
    ghLiquidNormal = normalize(mix(s.normal, normalize(vec3f(-slope.x, 1.0, -slope.y)), top));
#ifdef BLOXD_SCENE_DEPTH
    let behind = bloxdOpaqueBehind();
    if (behind.hit) {
        ghLiquidDepth = max(behind.distance - dist, 0.0);
        ghLiquidFloor = ghWorld(behind.position);
        ghLiquidFloorFound = true;
    }
#endif
    if (ghLiquidFloorFound) {
        let noise = ghNoise(world.xz * 3.0 + vec2f(ghTime() * 0.07));
        ghLiquidFoam = (1.0 - smoothstep(0.025, 0.48, ghLiquidDepth)) * top
            * (0.55 + noise * 0.45);
    }
    let transmittance = exp(-ghLiquidDepth * vec3f(0.32, 0.10, 0.055));
    output.colour = mix(vec3f(0.025, 0.10, 0.14), vec3f(0.12, 0.43, 0.40), transmittance);
#ifdef BLOXD_ALPHA
    let fresnel = ghFresnel(ghLiquidNormal, view);
    let depthOpacity = 1.0 - exp(-ghLiquidDepth * 0.20);
    output.alpha = clamp(0.30 + depthOpacity * 0.49 + fresnel * 0.34 + ghLiquidFoam * 0.22, 0.30, 0.96);
#endif
    return output;
}

fn bloxdLiquidLight(s: BloxdSurface, l: BloxdLightIn) -> BloxdLight {
    var output = bloxdDefaultLight(s, l);
    if (ghLiquidHot) {
        output.colour = ghRain(output.colour, l.position, ghRainExposure(l));
        return output;
    }
    let toEye = bloxdEyePosition() - l.position;
    let dist = max(length(toEye), 0.001);
    let view = toEye / dist;
    let outside = ghExposure(l);
    let sun = ghSun();
    let reflectedDirection = reflect(-view, ghLiquidNormal);
    let reflectedSky = ghSky(reflectedDirection);
    let fresnel = ghFresnel(ghLiquidNormal, view);
    let absorption = exp(-ghLiquidDepth * vec3f(0.23, 0.075, 0.035));
    let deep = vec3f(0.018, 0.13, 0.19) * (0.20 + 0.80 * outside);
    var colour = mix(deep, l.litColour, absorption);
    colour = mix(colour, reflectedSky * outside, clamp((0.10 + fresnel * 0.90) * outside, 0.0, 0.96));
    let sunDot = max(dot(reflectedDirection, sun), 0.0);
    let glint = pow(sunDot, 600.0) * 3.4 + pow(sunDot, 90.0) * 0.22;
    colour = colour + ghSunColour() * glint * outside * ghDay();
    let transmission = pow(max(dot(-view, sun), 0.0), 4.0);
    colour = colour + vec3f(0.035, 0.22, 0.15) * transmission * outside * ghDay();
    if (ghLiquidFloorFound && ghLiquidDepth < 9.0) {
        let p = ghLiquidFloor.xz;
        let t = ghTime();
        let stripes = sin(p.x * 3.1 + sin(p.y * 2.3 + t) * 1.3 + t * 0.8)
            * sin(p.y * 3.5 + sin(p.x * 1.9 - t * 0.7));
        let caustic = pow(max(1.0 - abs(stripes), 0.0), 12.0);
        colour = colour + vec3f(0.16, 0.22, 0.14) * caustic
            * exp(-ghLiquidDepth * 0.30) * outside * ghDay();
    }
    let foamColour = mix(vec3f(0.15, 0.20, 0.27), vec3f(0.89, 0.90, 0.83), ghDay());
    colour = mix(colour, foamColour, ghLiquidFoam * 0.72);
    colour = colour + vec3f(0.18, 0.23, 0.25) * ghLiquidRipple * outside;
    output.colour = ghRain(ghFinish(colour, s, l), l.position, ghRainExposure(l));
    return output;
}
