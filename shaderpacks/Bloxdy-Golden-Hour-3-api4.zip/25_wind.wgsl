// Strict games prohibit vertex displacement. Guard the hook declarations,
// leaving the complete surface/light look active in every strict variant.
#ifndef BLOXD_STRICT
fn bloxdTerrainVertex(v: BloxdVertexIn) -> BloxdVertex {
    var output = bloxdDefaultVertex(v);
    if (ghLeaf(v.blockFlags)) {
        let p = ghWorld(v.position);
        let t = ghTime();
        let gust = 0.65 + 0.35 * sin(p.x * 0.12 + p.z * 0.09 + t * 0.55);
        let sway = sin(p.x * 0.54 + p.z * 0.38 + t * 1.6);
        let flutter = sin(p.y * 2.6 + p.x * 1.1 + t * 3.1);
        output.position = output.position + vec3f(sway * 0.055,
            flutter * 0.008, sway * 0.031 + flutter * 0.012) * (gust * GH_WIND);
    }
    return output;
}

fn bloxdLiquidVertex(v: BloxdVertexIn) -> BloxdVertex {
    var output = bloxdDefaultVertex(v);
    if ((v.blockFlags & bloxdBlockFlagEmissive) == 0u) {
        let waves = ghWaves(ghWorld(v.position).xz, ghTime());
        // All faces share the displacement field so edges do not split.
        output.position.y = output.position.y + waves.x - GH_WATER_HEIGHT;
    }
    return output;
}
#endif
