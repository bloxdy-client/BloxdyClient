fn bloxdTerrainSurface(s: BloxdSurfaceIn) -> BloxdSurface {
    var output = bloxdDefaultSurface(s);
    if ((s.blockFlags & bloxdBlockFlagEmissive) != 0u) {
        return output;
    }
    let wet = ghPuddle(s.position, s.normal, s.blockFlags);
    output.colour = output.colour * (1.0 - wet * 0.24);
    return output;
}

fn bloxdTerrainLight(s: BloxdSurface, l: BloxdLightIn) -> BloxdLight {
    var output = bloxdDefaultLight(s, l);
    let normal = normalize(l.normal);
    let sun = ghSun();
    let day = ghDay();
    let outside = ghExposure(l);
    let lamp = ghLamp(l);
    let sunFacing = smoothstep(-0.18, 0.75, dot(normal, sun));
    var shade = 1.0;
#ifdef BLOXD_LIGHTING
    // Shape real engine skylight and occlusion; do not paint arbitrary tree
    // silhouettes. Keep interiors and lamps from receiving outdoor darkening.
    let skyLevel = ghSkyLevel(l.skyLight);
    let contact = smoothstep(13.75, 14.99, skyLevel);
    let canopy = clamp((1.0 - l.skyLight) / 0.0045, 0.0, 1.0)
        * smoothstep(0.48, 0.87, l.skyLight);
    shade = 1.0 - (1.0 - contact) * 0.28 * (1.0 - lamp) * day;
    shade = shade * (1.0 - canopy * 0.24 * (1.0 - lamp) * day);
#endif
    var colour = l.litColour;
    let emissive = (l.blockFlags & bloxdBlockFlagEmissive) != 0u;
    if (!emissive) {
        colour = colour * mix(vec3f(0.72, 0.81, 0.98), vec3f(1.12, 1.035, 0.88), sunFacing * outside * day) * shade;
        colour = colour + s.colour * ghSunColour() * (0.17 * sunFacing * outside * day * shade);
        if (normal.y < -0.4) {
            colour = colour * 0.88;
        }
    }

    let toEye = bloxdEyePosition() - l.position;
    let dist = max(length(toEye), 0.001);
    let view = toEye / dist;
    let wet = ghPuddle(l.position, normal, l.blockFlags) * outside;
    if (wet > 0.005) {
        let rippleFade = 1.0 - smoothstep(18.0, 38.0, dist);
        let ripple = ghRipple(ghWorld(l.position).xz, ghTime());
        let puddleNormal = normalize(vec3f(ripple.x * rippleFade * 0.45, 1.0, ripple.y * rippleFade * 0.45));
        let fresnel = ghFresnel(puddleNormal, view);
        let reflected = ghSky(reflect(-view, puddleNormal));
        colour = mix(colour, reflected, wet * clamp(0.10 + fresnel * 0.88, 0.0, 0.94));
        let halfVector = normalize(view + sun + vec3f(0.0, 0.0001, 0.0));
        let glint = pow(max(dot(puddleNormal, halfVector), 0.0), 260.0);
        colour = colour + ghSunColour() * (glint * wet * outside * day * 0.8);
        colour = colour + vec3f(0.16, 0.20, 0.24) * max(ripple.z, 0.0) * wet * rippleFade;
    }

    if (ghLeaf(l.blockFlags)) {
        let place = ghWorld(l.position);
        let flutter = sin(place.x * 1.8 + place.z * 0.9 + ghTime() * 2.2)
            * sin(place.y * 1.1 - ghTime() * 1.4);
        colour = colour * (1.0 + flutter * 0.095 * GH_WIND * outside);
        let backlight = pow(max(dot(-view, sun), 0.0), 3.0) * outside * day;
        colour = colour + s.colour * vec3f(1.0, 0.80, 0.27) * backlight * 0.18;
    }
    output.colour = ghRain(ghFinish(colour, s, l), l.position, ghRainExposure(l));
    return output;
}
