// Analytic rain streaks in a short, world-anchored volume in front of the
// visible surface. Shader-pack hooks do not run on the sky or entities.
// Eight bounded candidates, no extra textures, screen buffers or scene rays.
fn ghRain(colour: vec3f, position: vec3f, outside: f32) -> vec3f {
    if (GH_RAIN <= 0.0 || outside < 0.02) {
        return colour;
    }
    let eye = ghWorld(bloxdEyePosition());
    let visiblePoint = ghWorld(position);
    let segment = visiblePoint - eye;
    let dist = max(length(segment), 0.001);
    let ray = segment / dist;
    let span = min(dist - 0.06, GH_RAIN_RANGE);
    if (span < 0.8) {
        return colour;
    }
    let time = ghTime();
    let velocity = vec3f(0.45, -7.4, 0.20);
    let dropAxis = normalize(velocity);
    let drift = velocity * time;
    var coverage = 0.0;
    for (var i = 0; i < GH_RAIN_SAMPLES; i = i + 1) {
        let sampleDistance = (f32(i) + 0.45) * span / f32(GH_RAIN_SAMPLES);
        let samplePoint = eye + ray * sampleDistance;
        let cell = floor((samplePoint - drift) / 1.7);
        let seed = ghHash(cell.xz + cell.y * vec2f(17.13, 7.71));
        if (seed < GH_RAIN * 0.74) {
            let jitter = vec3f(ghHash(cell.xz + cell.y * 3.1),
                ghHash(cell.xz + cell.y * 11.7 + 29.0),
                ghHash(cell.xz + cell.y * 5.9 + 63.0));
            let centre = (cell + vec3f(0.18) + jitter * 0.64) * 1.7 + drift;
            let relative = centre - eye;
            let parallel = dot(ray, dropAxis);
            let denom = max(1.0 - parallel * parallel, 0.01);
            let rayDistance = (dot(ray, relative) - parallel * dot(dropAxis, relative)) / denom;
            let along = clamp(dot(eye + ray * rayDistance - centre, dropAxis), -0.30, 0.30);
            let dropPoint = centre + dropAxis * along;
            let nearest = clamp(dot(dropPoint - eye, ray), 0.0, span);
            let separation = length(dropPoint - (eye + ray * nearest));
            let width = 0.014 + nearest * 0.0011;
            let streak = 1.0 - smoothstep(width * 0.35, width, separation);
            let fade = smoothstep(0.3, 1.1, nearest) * (1.0 - smoothstep(11.0, GH_RAIN_RANGE, nearest));
            coverage = max(coverage, streak * fade);
        }
    }
    let rainColour = mix(vec3f(0.36, 0.45, 0.59), vec3f(0.81, 0.81, 0.74), ghDay());
    return mix(colour, rainColour, coverage * outside * 0.70);
}
